import os
import cv2
import argparse
import yaml
import numpy as np
import torch
import json
import torch.nn.functional as F
from dataloader.test_dataset import MedNeXtDataSet,EyeOCTTestDataSet
from torch.utils.data import DataLoader

#from criterion import CrossEntropy, OhemCrossEntropy
from omegaconf import OmegaConf
from dataloader.util import DataUpdater, seeding
from medpy.metric.binary import jc,dc, hd95, asd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from Model.semi_MedNeXt import KnowSAM,UNet_ablation,MedNeXt_ablation
from skimage.segmentation import find_boundaries
from medpy import metric
import matplotlib.pyplot as plt


def parse_option():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model_name', default='MedNeXt', type=str, help='model name')
    parser.add_argument('--model_config', default='config/transUnet.yaml', type=str, help='model config files')
    parser.add_argument('--num_classes', type=int, default=6,
                        help='output channel of network')
    parser.add_argument('--in_channels', type=int, default=3,
                        help='input channel of network')

    # parameters for data
    parser.add_argument('--dataset', type=str, default='eye', choices=['cervix', 'eye'], help='Dataset type')
    parser.add_argument('--frame_height', type=int, default=256, help='the frame height we used during training.')
    parser.add_argument('--frame_width', type=int, default=512, help='the frame width we used during training.')
    parser.add_argument('--ignore_label', type=int, default=-1, help='ignoring the label of pixels')

    # folder num，以便用于内部数据集的交叉验证
    parser.add_argument('--fold_num', type=int, default=0, choices=[0, 1, 2, 3, 4],
                        help='the fold num we used for cross validation.')
    parser.add_argument('--train_pattern', type=str, default="train",
                        choices=["train", "distill_label", "distill_unlabel"])
    parser.add_argument('--test_pattern', type=str, default="test")
    parser.add_argument('--pre_train', default=False, type=bool,
                        help="weight initialized by the weight pretrained from "
                             "imageNet")

    # test configuration
    parser.add_argument('--batch_size', type=int, default=1, help="training batch size")
    parser.add_argument('--num_workers', type=int, default=4, help="data loader thread")

    parser.add_argument('--gpu', type=int, default=0, help='the gpu number will be used')
    parser.add_argument('--checkpoint', type=str, default='checkpoint',
                        help='the directory to save the model weights.')
    parser.add_argument('--seed', default=42, type=int)
    parser.add_argument('--result_dir', default='result', type=str,
                        help='the directory of the model testing performance')
    parser.add_argument('--seg_model', default='KnowSAM', choices=['MedNeXt', 'KnowSAM'], help='选择分割模型')

    # loss
    parser.add_argument('--use_ohem', default=False, type=bool, help='whether use ohem for cross entropy')
    parser.add_argument('--ohemthres', default=0.9, type=float, help='threshold for ohem')
    parser.add_argument('--ohemkeep', type=int, default=125000, help='minimal numbers of ohem')


    args = parser.parse_args()
    return args


def calculate_dice(tp, pos, res):
    """
    计算 Dice 系数
    :param tp: True Positives 数组
    :param pos: Ground Truth 总数
    :param res: 预测结果总数
    :return: Dice 系数
    """
    return (2 * tp) / np.maximum(1.0, pos + res)


def path_determine(args):
    param_pattern = 'ade20k_pretrain' if args.pre_train else 'random_initial'
    # model_name = args.model_config.split('/')[-1].split('.')[0]
    model_name = args.model_name
    args.directory_path = os.path.join(args.train_pattern, model_name, param_pattern, str(args.fold_num))
    args.weight_path = os.path.join('checkpoint', args.directory_path, 'MedNeXt_checkpoint_huafen337.pth')
    args.result_dir = os.path.join('result', args.directory_path)
    os.makedirs(args.result_dir, exist_ok=True)
    return args



def load_weight(model):
    directory_path = os.path.join('train', 'MedNeXt', 'random_initial', '2')
    #weight_path = os.path.join('checkpoint',directory_path, 'MedNeXt_checkpoint_huafen337.pth')
    weight_path = os.path.join('checkpoint', directory_path, 'MedNeXt_checkpoint_256_1000.pth')
    #weight_path = os.path.join(weight_path, 'segmodel_checkpoint.pth')
    # 加载模型权重
    print('==> loading seg model')
    checkpoint = torch.load(weight_path, map_location='cpu')
    model_dict = checkpoint['state_dict']
    state = model.load_state_dict(model_dict, strict=False)
    print('loading checkpoint from {}'.format(weight_path))
    print(state)
    return model

def load_KnowSAM_weight(model):

    weight_path = os.path.join('Results/eye/oct_full/SGDL_best_model.pth')
    # 加载模型权重
    print('==> loading seg model')
    state = model.load_state_dict(torch.load(weight_path), strict=True)
    print('loading checkpoint from {}'.format(weight_path))
    print(state)
    return model

# 彩色化分割结果的函数
def colorize_segmentation(segmentation):
    """
    根据分割的类别信息进行彩色化处理
    :param segmentation: 分割结果（类别图）
    :return: 彩色化的分割结果
    """
    colormap = np.array([
        [128, 128, 128],  # 灰色
        [0, 0, 0],  # 黑色 背景
        [255, 255, 255],  # 白色 上皮
        [128, 0, 128],  # 紫色   间隙
        [0, 0, 255],  # 蓝色  凸起
        [255, 0, 0],  # 红色  保护套
        [42, 42, 165],  # 棕色    囊肿
        [0, 255, 0],  # 绿色   基质
    ])
    colorized = colormap[segmentation]  # 根据类别映射生成彩色图
    return colorized

# 保存函数
def save_segmentation_and_colorized(pred_seg, image_name, label, pred_folder, color_folder):
    """
    保存分割结果和彩色化的分割结果
    :param pred_seg: 预测的分割图
    :param image_name: 图像名称，用于保存
    :param label: 当前图像的标签，根据标签决定保存的子文件夹
    :param pred_folder: 保存分割结果的文件夹路径
    :param color_folder: 保存彩色化结果的文件夹路径
    """
    # 将标签转换为字符串
    label_str = str(label.item()) if isinstance(label, torch.Tensor) else str(label)

    # 根据标签创建子文件夹（以标签作为子文件夹的名字）
    label_pred_folder = os.path.join(pred_folder, label_str)
    label_color_folder = os.path.join(color_folder, label_str)

    # 如果文件夹不存在，则创建它们
    os.makedirs(label_pred_folder, exist_ok=True)
    os.makedirs(label_color_folder, exist_ok=True)

    # 保存分割图（以类别为值的图像）
    pred_image_path = os.path.join(label_pred_folder, image_name)
    cv2.imwrite(pred_image_path, pred_seg)

    # 彩色化分割结果
    colorized_image = colorize_segmentation(pred_seg)

    # 保存彩色化的分割结果
    color_image_path = os.path.join(label_color_folder, image_name)
    cv2.imwrite(color_image_path, colorized_image)


def test_seg(model, test_loader, config, pred_folder, color_folder):
    if config.dataset == 'cervix':
        num_classes = 8
    elif config.dataset == 'eye' :
        num_classes = 6
    else:
        raise ValueError(f"Unsupported dataset: {args.dataset}")

    # 每个类别分别存指标
    class_metrics = {
        i: {'dice': [], 'iou': [], 'asd': [], 'hd95': []}
        for i in range(1, num_classes)  # 通常跳过 background=0
    }

    model.eval()
    ave_loss = DataUpdater()

    device = next(model.parameters()).device

    final_res = [0, 0, 0, 0]

    # 创建保存文件夹
    os.makedirs(pred_folder, exist_ok=True)
    os.makedirs(color_folder, exist_ok=True)

    # 初始化类别像素计数
    # total_pixels = np.zeros(config.num_class)  # 假设有config.num_class个类别
    # total_class_counts = np.zeros(config.num_class)  # 记录每个类别出现的像素数量

    with torch.no_grad():
        for idx, batch in enumerate(test_loader):
            images, masks, labels, image_paths, mask_paths = batch  # 假设 `image_paths` 是原图路径
            images = images.to(device, non_blocking=True)
            masks = masks.long().to(device, non_blocking=True)  # [B, H, W]

            pred_seg, _, _, _, _ = model(images)
            # Resize pred_seg 和 masks 到 256x512
            # pred_seg = F.interpolate(pred_seg, size=(256, 512), mode='bilinear', align_corners=True)
            # masks = F.interpolate(masks.unsqueeze(1).float(), size=(256, 512), mode='nearest').squeeze(1).long()  # masks需要unsqueeze再resize
            pred_np = torch.argmax(pred_seg, dim=1).cpu().numpy()
            masks_np = masks.cpu().numpy()

            # 累加每个类别的像素数
            # for i in range(config.num_class):
            #     total_class_counts[i] += np.sum(masks_np == i)
            #     total_pixels[i] += masks_np.size  # 总像素数

            # #保存分割图和彩色化图
            # for i, image_path in enumerate(image_paths):
            #     image_name = os.path.basename(image_path)  # 获取原图的文件名
            #     save_segmentation_and_colorized(pred_np[i], image_name,labels[i], pred_folder, color_folder)

            metric_list = []

            for c in range(1, num_classes):
                pred_c = (pred_np == c).astype(np.uint8)
                gt_c = (masks_np == c).astype(np.uint8)

                if pred_c.sum() == 0 and gt_c.sum() == 0:
                    continue

                if pred_c.sum() > 0 and gt_c.sum() > 0:
                    dice = metric.binary.dc(pred_c, gt_c)
                    iou = metric.binary.jc(pred_c, gt_c)
                    asd_ = metric.binary.asd(pred_c, gt_c)
                    hd_ = metric.binary.hd95(pred_c, gt_c)

                    metric_list.append([dice, iou, asd_, hd_])

                    class_metrics[c]['dice'].append(dice)
                    class_metrics[c]['iou'].append(iou)
                    class_metrics[c]['asd'].append(asd_)
                    class_metrics[c]['hd95'].append(hd_)


                else:
                    print(f"Skipping class {c} due to no foreground")

            metric_list = np.array(metric_list).astype("float32")
            metric_list = np.mean(metric_list, axis=0)

            print(metric_list)
            final_res += metric_list

        #计算类别权重：根据频率反比
        # class_weights = total_pixels / total_class_counts  # 类别频率的反比
        # class_weights = class_weights / np.sum(class_weights)  # 归一化权重
        # print("Class weights:", class_weights)

        final_res = [x / len(test_loader) for x in final_res]
        print("avg_dice: ", final_res[0])
        print("avg_iou: ", final_res[1])
        print("avg_asd: ", final_res[2])
        print("avg_hd95: ", final_res[3])

        print("\n===== Per-class Average Metrics =====")
        for c in class_metrics:
            if len(class_metrics[c]['dice']) == 0:
                print(f"Class {c}: skipped (no samples)")
                continue

            print(
                f"Class {c}: "
                f"Dice={np.mean(class_metrics[c]['dice']):.4f}, "
                f"IoU={np.mean(class_metrics[c]['iou']):.4f}, "
                f"ASD={np.mean(class_metrics[c]['asd']):.2f}, "
                f"HD95={np.mean(class_metrics[c]['hd95']):.2f}"
            )

    return final_res[0], final_res[1], final_res[2], final_res[3]


def worker(args):
    args = path_determine(args)
    # 定义dataloader
    if args.dataset == 'cervix':
        test_data = MedNeXtDataSet(args=args, pattern=args.test_pattern)
        test_loader = DataLoader(test_data, batch_size=args.batch_size, num_workers=args.num_workers, shuffle=False)
    elif args.dataset == 'eye' :
        test_data = EyeOCTTestDataSet(args=args)
        test_loader = DataLoader(test_data, batch_size=args.batch_size, num_workers=args.num_workers, shuffle=False)
    else:
        raise ValueError(f"Unsupported dataset: {args.dataset}")
    # # 定义模型
    # model = get_MedNeXt_model()
    # #model = KnowSAM()
    # print(f"fold_num: {args.fold_num}")
    # model = load_weight(model)
    # #model = load_KnowSAM_weight(model)


    model = KnowSAM(args)
    #model = UNet_ablation(args)
    #model = MedNeXt_ablation(args)
    model = load_KnowSAM_weight(model)

    device = torch.device('cuda:' + str(args.gpu))
    model = model.to(device)

    # 在 worker 函数中调用时，提供保存路径
    pred_folder = "result/KnowSAM_mednext_mednext1000_7/pred"
    color_folder = "result/KnowSAM_mednext_mednext1000_7/pred_color"
    test_seg(model, test_loader, args, pred_folder, color_folder)




if __name__ == '__main__':
    # set seed for reproduce
    args = parse_option()
    seeding(args.seed)
    #for fold_num in [2]:
    #args.fold_num = fold_num
    worker(args)
