import torch
import torch.nn.functional as F
import torch.nn as nn
import numpy as np
from utils.losses import dice_loss, loss_diff1, loss_diff2, KDLoss, OCTDiceLoss, StructureContrastiveLoss
from Model.semi_MedNeXt import KnowSAM,UNet_ablation,MedNeXt_ablation
import logging
import torch.optim.lr_scheduler as lr_scheduler

class MC_Trainer(object):
    def __init__(self, args):
        self.args = args
        self.criterion_mse = nn.MSELoss()
        device = torch.device(f"cuda:{args.gpu}")
        self.device = device
        self.model = KnowSAM(args).to(device).train()
        #self.model = UNet_ablation(args).to(device).train()
        #self.model = MedNeXt_ablation(args).to(device).train()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=args.lr)
        self.class_weights = torch.tensor(args.class_weights, dtype=torch.float).to(device)
        self.dice_loss = OCTDiceLoss(args.num_classes, self.class_weights)
        self.structure_loss = StructureContrastiveLoss(args)
        # 添加学习率衰减器（使用CosineAnnealingLR作为例子）
        self.scheduler = lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=args.max_iterations, eta_min=1e-6)

    def sigmoid_rampup(self, current, rampup_length):
        """Exponential rampup from https://arxiv.org/abs/1610.02242"""
        if rampup_length == 0:
            return 1.0
        else:
            current = np.clip(current, 0.0, rampup_length)
            phase = 1.0 - current / rampup_length
            return float(np.exp(-5.0 * phase * phase))

    def entropy_loss(self, p, C=2):
        y1 = -1 * torch.sum(p * torch.log(p + 1e-6), dim=1) / torch.tensor(np.log(C)).to(self.device)
        ent = torch.mean(y1)
        return ent

    def get_entropy_map(self, p):
        ent_map = -1 * torch.sum(p * torch.log(p + 1e-6), dim=1, keepdim=True)
        return ent_map

    def get_current_consistency_weight(self, epoch):
        return self.args.consistency * self.sigmoid_rampup(epoch, self.args.consistency_rampup)

    def train(self, volume_batch, label_batch, iter_num):
        labeled_bs = self.args.labeled_bs
        inputs_x = volume_batch[:labeled_bs]
        targets_x = label_batch[:labeled_bs]
        inputs_u = volume_batch[labeled_bs:]

        self.model.train()
        self.optimizer.zero_grad()

        # Forward
        pred1, pred2, pred1_soft, pred2_soft, fusion_map = self.model(volume_batch)

        # 有标签部分 supervised loss
        loss_sup1 = F.cross_entropy(pred1[:labeled_bs], targets_x, weight=self.class_weights)
        loss_sup2 = F.cross_entropy(pred2[:labeled_bs], targets_x, weight=self.class_weights)
        cls_loss = loss_sup1 + loss_sup2

        # 无标签部分 pseudo-label CPS loss
        # Pseudo-labels
        pseudo_label1 = pred2_soft[labeled_bs:].max(1)[1]
        pseudo_label2 = pred1_soft[labeled_bs:].max(1)[1]

        # Confidence mask
        max_prob2 = pred2_soft[labeled_bs:].max(1)[0]
        mask2 = (max_prob2 > self.args.conf_thresh).float()

        max_prob1 = pred1_soft[labeled_bs:].max(1)[0]
        mask1 = (max_prob1 > self.args.conf_thresh).float()

        # Per-pixel CE
        loss_cps1 = F.cross_entropy(pred1[labeled_bs:], pseudo_label1, reduction='none')
        loss_cps2 = F.cross_entropy(pred2[labeled_bs:], pseudo_label2, reduction='none')

        # Apply confidence mask
        loss_cps1 = torch.mean(loss_cps1 * mask2)
        loss_cps2 = torch.mean(loss_cps2 * mask1)
        cps_loss = loss_cps1 + loss_cps2

        # dice loss for supervised (labeled) samples
        dice_loss1 = self.dice_loss(pred1_soft[:labeled_bs], targets_x)
        dice_loss2 = self.dice_loss(pred2_soft[:labeled_bs], targets_x)
        dic_loss = dice_loss1 + dice_loss2

        # ✅ 熵损失：只对无标签样本计算
        pred1_loss = self.entropy_loss(pred1_soft[labeled_bs:], C=8)
        pred2_loss = self.entropy_loss(pred2_soft[labeled_bs:], C=8)
        entropy_loss = pred1_loss + pred2_loss

        # ✅ 动态一致性权重
        cons_weight = self.get_current_consistency_weight(
            iter_num // int(self.args.max_iterations / self.args.consistency_rampup)
        )

        # 总loss
        loss = cls_loss + dic_loss  + cons_weight * cps_loss  + 0.9 * entropy_loss

        loss.backward()
        self.optimizer.step()
        self.scheduler.step()

        current_lr = self.optimizer.param_groups[0]['lr']

        # 日志记录
        logging.info(
            'iteration %d : CLS_loss : %.4f | CPS_loss : %.4f | Dice_loss : %.4f | Entropy : %.4f | LR : %.6f | Cons_weight : %.4f',
            iter_num, cls_loss.item(), cps_loss.item(), dic_loss.item(), entropy_loss.item(), current_lr, cons_weight)

        return cls_loss.item(), dic_loss.item(), cps_loss.item(), entropy_loss.item()

        # 日志记录
        # logging.info(
        #     'iteration %d : CLS_loss : %.4f | Dice_loss : %.4f | LR : %.6f ',
        #     iter_num, cls_loss.item(),  dic_loss.item(),  current_lr)
        #
        # return cls_loss.item(), dic_loss.item(), 0.0, 0.0  # entropy_loss.item()
