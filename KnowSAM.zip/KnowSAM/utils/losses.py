import torch
import torch.nn as nn
from torch.autograd import Variable
from torch.nn import functional as F
CE = torch.nn.BCELoss()
mse = torch.nn.MSELoss()

class KDLoss(nn.Module):
    """
    Distilling the Knowledge in a Neural Network
    https://arxiv.org/pdf/1503.02531.pdf
    """

    def __init__(self, T):
        super(KDLoss, self).__init__()
        self.T = T

    def forward(self, out_s, out_t):
        loss = (
            F.kl_div(F.log_softmax(out_s / self.T, dim=1),
                     F.softmax(out_t / self.T, dim=1), reduction="batchmean")  # , reduction="batchmean"
            * self.T
            * self.T
        )
        return loss


def loss_diff1(u_prediction_1, u_prediction_2):
    loss_a = 0.0

    for i in range(u_prediction_2.size(1)):
        loss_a = CE(u_prediction_1[:, i, ...].clamp(1e-8, 1 - 1e-7),
                                 Variable(u_prediction_2[:, i, ...].float(), requires_grad=False))

    loss_diff_avg = loss_a.mean()
    return loss_diff_avg


def loss_diff2(u_prediction_1, u_prediction_2):
    loss_b = 0.0

    for i in range(u_prediction_2.size(1)):
        loss_b = CE(u_prediction_2[:, i, ...].clamp(1e-8, 1 - 1e-7),
                                 Variable(u_prediction_1[:, i, ...], requires_grad=False))

    loss_diff_avg = loss_b.mean()
    return loss_diff_avg


class DiceLoss(nn.Module):
    def __init__(self, n_classes):
        super(DiceLoss, self).__init__()
        self.n_classes = n_classes

    def _one_hot_encoder(self, input_tensor):
        tensor_list = []
        for i in range(self.n_classes):
            temp_prob = input_tensor * i == i * torch.ones_like(input_tensor)
            tensor_list.append(temp_prob)
        output_tensor = torch.cat(tensor_list, dim=1)
        return output_tensor.float()

    def _dice_loss(self, score, target):
        target = target.float()
        smooth = 1e-10
        intersect = torch.sum(score * target)
        y_sum = torch.sum(target * target)
        z_sum = torch.sum(score * score)
        loss = (2 * intersect + smooth) / (z_sum + y_sum + smooth)
        loss = 1 - loss
        return loss

    def _dice_mask_loss(self, score, target, mask):
        target = target.float()
        mask = mask.float()
        smooth = 1e-10
        intersect = torch.sum(score * target * mask)
        y_sum = torch.sum(target * target * mask)
        z_sum = torch.sum(score * score * mask)
        loss = (2 * intersect + smooth) / (z_sum + y_sum + smooth)
        loss = 1 - loss
        return loss

    def forward(self, inputs, target, weight=None, softmax=False):
        if softmax:
            inputs = torch.softmax(inputs, dim=1)
        target = self._one_hot_encoder(target.unsqueeze(1))
        if weight is None:
            weight = [1] * self.n_classes
        assert inputs.size() == target.size(), 'predict & target shape do not match'
        class_wise_dice = []
        loss = 0.0
        for i in range(0, self.n_classes):
            dice = self._dice_loss(inputs[:, i], target[:, i])
            class_wise_dice.append(1.0 - dice.item())
            loss += dice * weight[i]
        return loss / self.n_classes


def dice_loss(pred, label, epsilon=1e-5):
    intersection = torch.sum(pred * label, dim=(2, 3))
    union = torch.sum(pred, dim=(2, 3)) + torch.sum(label, dim=(2, 3))
    dice_coefficient = (2.0 * intersection + epsilon) / (union + epsilon)
    dice_loss = 1.0 - dice_coefficient
    return dice_loss.mean()


def sigmoid_mse_loss_map(input_logits, target_logits):
    assert input_logits.size() == target_logits.size()
    input_softmax = torch.nn.Sigmoid()(input_logits)
    target_softmax = torch.nn.Sigmoid()(target_logits)
    mse_loss_map = (input_softmax-target_softmax)**2
    return mse_loss_map


def mse_loss(input1, input2):
    return torch.mean((input1 - input2) ** 2)


class DiceLoss(nn.Module):
    def __init__(self, n_classes):
        super(DiceLoss, self).__init__()
        self.n_classes = n_classes

    def _one_hot_encoder(self, input_tensor):
        tensor_list = []
        for i in range(self.n_classes):
            temp_prob = input_tensor == i * torch.ones_like(input_tensor)
            tensor_list.append(temp_prob)
        output_tensor = torch.cat(tensor_list, dim=1)
        return output_tensor.float()

    def _one_hot_mask_encoder(self, input_tensor):
        tensor_list = []
        for i in range(self.n_classes):
            temp_prob = input_tensor * i == i * torch.ones_like(input_tensor)
            tensor_list.append(temp_prob)
        output_tensor = torch.cat(tensor_list, dim=1)
        return output_tensor.float()

    def _dice_loss(self, score, target):
        target = target.float()
        smooth = 1e-10
        intersect = torch.sum(score * target)
        y_sum = torch.sum(target * target)
        z_sum = torch.sum(score * score)
        loss = (2 * intersect + smooth) / (z_sum + y_sum + smooth)
        loss = 1 - loss
        return loss

    def _dice_mask_loss(self, score, target, mask):
        target = target.float()
        mask = mask.float()
        smooth = 1e-10
        intersect = torch.sum(score * target * mask)
        y_sum = torch.sum(target * target * mask)
        z_sum = torch.sum(score * score * mask)
        loss = (2 * intersect + smooth) / (z_sum + y_sum + smooth)
        loss = 1 - loss
        return loss

    def forward(self, inputs, target, mask=None, weight=None, softmax=False):
        if softmax:
            inputs = torch.softmax(inputs, dim=1)
        target = self._one_hot_encoder(target.unsqueeze(1))
        if weight is None:
            weight = [1] * self.n_classes
        assert inputs.size() == target.size(), 'predict & target shape do not match'
        class_wise_dice = []
        loss = 0.0
        if mask is not None:
            mask = self._one_hot_mask_encoder(mask)
            for i in range(0, self.n_classes):
                dice = self._dice_mask_loss(inputs[:, i], target[:, i], mask[:, i])
                class_wise_dice.append(1.0 - dice.item())
                loss += dice * weight[i]
        else:
            for i in range(0, self.n_classes):
                dice = self._dice_loss(inputs[:, i], target[:, i])
                class_wise_dice.append(1.0 - dice.item())
                loss += dice * weight[i]
        return loss / self.n_classes

class OCTDiceLoss(nn.Module):
    def __init__(self, n_classes, weight=None, ignore_index=None, smooth=1e-5):
        super(OCTDiceLoss, self).__init__()
        self.n_classes = n_classes
        self.weight = weight if weight is not None else [1.0] * n_classes
        self.ignore_index = ignore_index
        self.smooth = smooth

    def forward(self, probs, target):
        """
        probs:  [B, C, H, W]  (softmax output, probability map)
        target: [B, H, W]     (ground truth label map)
        """
        assert probs.shape[1] == self.n_classes, "Mismatch in class count"

        # One-hot encode target
        target_onehot = F.one_hot(target, num_classes=self.n_classes)  # [B, H, W, C]
        target_onehot = target_onehot.permute(0, 3, 1, 2).float()      # [B, C, H, W]

        loss = 0.0
        valid_classes = 0

        for c in range(self.n_classes):
            if self.ignore_index is not None and c == self.ignore_index:
                continue

            prob = probs[:, c]            # [B, H, W]
            gt = target_onehot[:, c]      # [B, H, W]

            # 如果该类别在GT中不存在，跳过
            if torch.sum(gt) == 0:
                continue

            intersection = torch.sum(prob * gt)
            union = torch.sum(prob) + torch.sum(gt)
            dice = (2.0 * intersection + self.smooth) / (union + self.smooth)

            loss += self.weight[c] * (1.0 - dice)
            valid_classes += 1

        if valid_classes == 0:
            return torch.tensor(0.0, requires_grad=True, device=probs.device)

        return loss / valid_classes

#结构对比损失
class StructureContrastiveLoss:
    def __init__(self, temperature=0.1, num_samples=10, entropy_thresh=0.5):
        self.temperature = temperature
        self.num_samples = num_samples
        self.entropy_thresh = entropy_thresh

    def get_entropy_map(self, prob_map):
        # prob_map: [B, C, H, W], softmaxed output
        entropy_map = -torch.sum(prob_map * torch.log(prob_map + 1e-6), dim=1, keepdim=True)
        return entropy_map  # [B, 1, H, W]

    def sample_patches(self, features, mask):
        # features: [B, C, H, W]; mask: [B, 1, H, W] (0 or 1)
        B, C, H, W = features.shape
        sampled = []
        for b in range(B):
            coords = torch.nonzero(mask[b, 0], as_tuple=False)
            if coords.shape[0] >= self.num_samples:
                idx = torch.randperm(coords.shape[0])[:self.num_samples]
                sampled_coords = coords[idx]
                for yx in sampled_coords:
                    y, x = yx
                    feat = features[b, :, y, x]
                    sampled.append(feat)
        if sampled:
            return torch.stack(sampled)  # [N, C]
        else:
            return None

    def __call__(self, fusion_map, pred_soft):
        # fusion_map: [B, C, H, W]; pred_soft: [B, C, H, W] (after softmax)
        entropy_map = self.get_entropy_map(pred_soft)  # [B, 1, H, W]
        pos_mask = (entropy_map < self.entropy_thresh).float()
        neg_mask = (entropy_map >= self.entropy_thresh).float()

        pos_feats = self.sample_patches(fusion_map, pos_mask)
        neg_feats = self.sample_patches(fusion_map, neg_mask)

        if pos_feats is None or neg_feats is None:
            return torch.tensor(0.0, device=fusion_map.device, requires_grad=True)

        feats = torch.cat([pos_feats, neg_feats], dim=0)  # [N+M, C]
        feats = F.normalize(feats, dim=1)

        sim_matrix = torch.matmul(feats, feats.T)  # [N+M, N+M]
        sim_matrix /= self.temperature

        labels = torch.cat([
            torch.ones(len(pos_feats)),
            torch.zeros(len(neg_feats))
        ], dim=0).to(fusion_map.device)

        targets = torch.eye(len(feats), device=fusion_map.device)
        loss = F.cross_entropy(sim_matrix, targets.argmax(dim=1))
        return loss
