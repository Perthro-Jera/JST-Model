import os
import sys
import random
import cv2
import numpy as np
import torch
import itertools
import pandas as pd
from torch.utils.data import Dataset
import albumentations as A
from torch.utils.data.sampler import Sampler
from .util import ImageProcessor
import tifffile
from albumentations.pytorch import ToTensorV2


def verify_file_paths(image_paths, mask_paths):
    invalid_image_paths = [path for path in image_paths if not os.path.isfile(path)]
    invalid_mask_paths = [path for path in mask_paths if not os.path.isfile(path)]

    if invalid_image_paths:
        print(f"以下图像文件路径无效: {invalid_image_paths}")
    if invalid_mask_paths:
        print(f"以下标签文件路径无效: {invalid_mask_paths}")

    return len(invalid_image_paths) == 0 and len(invalid_mask_paths) == 0


def verify_clsfile_paths(image_paths):
    invalid_image_paths = [path for path in image_paths if not os.path.isfile(path)]
    if invalid_image_paths:
        print(f"以下图像文件路径无效: {invalid_image_paths}")

    return len(invalid_image_paths) == 0

class MedNeXtDataSet(Dataset):

    def __init__(self, args, pattern='train'):
        self.args = args
        self.pattern = pattern
        self.imgs, self.masks, self.labels = self.__load_file(pattern=pattern, fold_num=args.fold_num)

        if not verify_file_paths(self.imgs, self.masks):
            raise ValueError("检测到无效的文件路径，请检查输入数据文件")
        print(f"fold_num: {self.args.fold_num}")
        print(f"num of samples {len(self.imgs)}")
        self.img_processor = ImageProcessor(args, augmentation=pattern)

    def __getitem__(self, index):
        if self.pattern in ["train", "test", "distill_label"]:
            imgPath = self.imgs[index]
            maskPath = self.masks[index]
            label = self.labels[index]

            # 根据路径读取图片和mask标签
            img = cv2.imread(imgPath)  # ndarray [H, W, 3]
            mask = cv2.imread(maskPath, cv2.IMREAD_GRAYSCALE)  # ndarray [H, W]
            image, mask = self.img_processor(img, mask)  # Tensor [3, H, W], Tensor [H, W]

            return [image, mask, label, imgPath, maskPath]

        elif self.pattern in ["distill_unlabel", 'predict']:
            imgPath = self.imgs[index]
            img = cv2.imread(imgPath)  # ndarray [H, W, 3]
            image, mask = self.img_processor(img, None)  # Tensor [3, H, W], None
            return [image, imgPath]

    def __len__(self):
        return len(self.imgs)

    def __load_file(self, pattern="train", fold_num=0):
        if pattern in ["train", "test", "distill_label"]:
            file_path = os.path.join("dataloader", "data_huafen.xlsx")
            #file_path = os.path.join("dataset", "data337.xlsx")
            l_d = {0: '第一折', 1: '第二折', 2: '第三折', 3: '第四折', 4: '第五折'}
            df_frame = pd.read_excel(file_path, sheet_name=l_d[fold_num])
            # 将label转化为整形
            #label_map = {'宫颈炎': 0, '囊肿': 1, '外翻': 2, '高级别病变': 3, '宫颈癌': 4,}  # Example mapping
            label_map = {'宫颈炎': 0, '囊肿': 1, '外翻': 2 }
            if pattern in ["train", "distill_label"]:
                # 这个地方先注释掉，后面真正进行5折时再修改回来
                # df_frame = df_frame.iloc[:int(len(df_frame) * 0.8), :]
                pass
            else:
                # 这个地方先注释掉，后面真正进行5折时再修改回来
                # df_frame = df_frame.iloc[int(len(df_frame) * 0.8):, :]
                df_frame = pd.read_excel(file_path, sheet_name=l_d[1])
                pass
            # Filter out rows where label is not in label_map
            df_frame = df_frame[df_frame['label'].isin(label_map.keys())]
            # Map labels to integers
            df_frame['label'] = df_frame['label'].map(label_map)

            df_frame.reset_index(drop=True, inplace=True)
            # 接下来返回文件名列表和frame类别列表
            image_paths = df_frame['image_path'].tolist()
            mask_paths = df_frame['mask_path'].tolist()
            labels = df_frame['label'].tolist()
            return image_paths, mask_paths, labels
        elif pattern in ["distill_unlabel"]:
            file_path = os.path.join("dataset", "unlabeled_data.xlsx")
            df_frame = pd.read_excel(file_path, sheet_name="原始数据")
            image_paths = df_frame['image_path'].tolist()
            return image_paths, [], []
        elif pattern in ["predict"]:
            file_path = os.path.join("dataset", "data_A5.xlsx")
            df_frame = pd.read_excel(file_path, sheet_name="第三折")
            # 我们只读取宫颈炎，囊肿，外翻的图像用来预测分割掩码
            # df_frame = df_frame[df_frame['类别'].isin([3, 4])]
            # df_frame = df_frame[df_frame['类别'].isin(['宫颈炎', '囊肿', '外翻'])]
            image_paths = df_frame['image_path'].tolist()
            print(f'预测的图片总数为{len(image_paths)}')
            return image_paths, [], []


class EyeOCTTestDataSet(Dataset):
    def __init__(self, args, pattern='test'):
        self.args = args
        self.pattern = pattern

        # 和你原来一致：xlsx / csv 里读路径
        self.imgs, self.masks, self.labels = self.__load_file(
            pattern=pattern,
            fold_num=args.fold_num
        )

        if not verify_file_paths(self.imgs, self.masks):
            raise ValueError("检测到无效的文件路径，请检查输入数据文件")

        print(f"[EyeOCT] fold_num: {self.args.fold_num}")
        print(f"[EyeOCT] num of samples: {len(self.imgs)}")

    def __len__(self):
        return len(self.imgs)

    def __getitem__(self, index):
        imgPath = self.imgs[index]
        maskPath = self.masks[index]
        label = self.labels[index]

        H, W = self.args.frame_height, self.args.frame_width

        # ===================== 1. 读取 TIFF image =====================
        if imgPath.endswith(".tif") or imgPath.endswith(".tiff"):
            img = tifffile.imread(imgPath)
        else:
            img = cv2.imread(imgPath, cv2.IMREAD_UNCHANGED)

        # ---- 通道处理 ----
        if img.ndim == 2:
            img = np.stack([img] * 3, axis=-1)
        elif img.ndim == 3 and img.shape[2] == 1:
            img = np.repeat(img, 3, axis=2)

        # ---- 强制 resize（和官方原始代码一致）----
        img = cv2.resize(img, (W, H), interpolation=cv2.INTER_LINEAR)

        # ---- 归一化 ----
        if img.dtype == np.uint16:
            img = img.astype(np.float32) / 65535.0
        else:
            img = img.astype(np.float32) / 255.0

        # ===================== 2. 读取 PNG mask =====================
        mask = cv2.imread(maskPath, cv2.IMREAD_GRAYSCALE)
        mask = cv2.resize(mask, (W, H), interpolation=cv2.INTER_NEAREST)
        mask = mask.astype(np.int64)

        # ===================== 3. Normalize（不再用 Albumentations） =====================
        img = img.astype(np.float32)
        img = (img - img.mean()) / (img.std() + 1e-6)

        # HWC → CHW
        img = torch.from_numpy(img.transpose(2, 0, 1)).float()
        mask = torch.from_numpy(mask).long()

        return [img, mask, label, imgPath, maskPath]

    def __load_file(self, pattern="test", fold_num=0):
        """
        Eye OCT test dataset
        xlsx:
            sheet 0: train
            sheet 1: test
        """
        if pattern not in ["train", "test", "distill_label"]:
            raise ValueError(f"Unsupported pattern: {pattern}")

        file_path = os.path.join("dataloader", "oct5k_segmentation.xlsx")

        # ================== 关键修改在这里 ==================
        if pattern == "test":
            df = pd.read_excel(file_path, sheet_name=1)  # 第二个工作表
        else:
            df = pd.read_excel(file_path, sheet_name=0)  # 第一个工作表
        # ====================================================

        # 基本检查
        required_cols = ["image_path", "mask_path", "label"]
        for col in required_cols:
            if col not in df.columns:
                raise ValueError(f"xlsx 缺少必要列: {col}")

        # 去掉路径为空的样本
        df = df.dropna(subset=["image_path", "mask_path"])
        df.reset_index(drop=True, inplace=True)

        image_paths = df["image_path"].tolist()
        mask_paths = df["mask_path"].tolist()
        labels = df["label"].tolist()  # eye OCT 不做映射

        return image_paths, mask_paths, labels



