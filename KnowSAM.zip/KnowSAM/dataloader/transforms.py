import albumentations as A
import cv2
import random
from albumentations.pytorch.transforms import ToTensorV2

def build_transforms(args):
    data_transforms = {
        "train": A.Compose([
            A.OneOf([
                A.Resize(*[args.image_size, args.image_size], interpolation=cv2.INTER_NEAREST, p=1.0),
            ], p=1),

            A.HorizontalFlip(p=0.5),
            A.VerticalFlip(p=0.5),
            A.ShiftScaleRotate(shift_limit=0.0625, scale_limit=0.05, rotate_limit=10, p=0.5),
            A.OneOf([
                A.GridDistortion(num_steps=5, distort_limit=0.05, p=1.0),
                A.ElasticTransform(alpha=1, sigma=50, alpha_affine=50, p=1.0)
            ], p=0.25),
            A.CoarseDropout(max_holes=8, max_height=args.image_size // 20, max_width=args.image_size // 20,
                            min_holes=5, fill_value=0, mask_fill_value=0, p=0.5),
        ], p=1.0),


        "valid_test": A.Compose([
            A.Resize(*[args.image_size, args.image_size], interpolation=cv2.INTER_NEAREST),
        ], p=1.0)
    }
    return data_transforms


def build_weak_strong_transforms(args):
    data_transforms = {
        "train_weak":
            A.Compose([
                A.OneOf([A.Resize(*[args.image_size, args.image_size], interpolation=cv2.INTER_NEAREST, p=1.0),], p=1),
                A.HorizontalFlip(p=0.5),
                A.VerticalFlip(p=0.5),
                A.RandomBrightnessContrast(p=0.2),
                A.ShiftScaleRotate(shift_limit=0.0625, scale_limit=0.05, rotate_limit=10, p=0.5),
                # A.OneOf([A.GridDistortion(num_steps=5, distort_limit=0.05, p=1.0),
                #         A.ElasticTransform(alpha=1, sigma=50, alpha_affine=50, p=1.0)
                #         ], p=0.25),
                A.CoarseDropout(max_holes=8, max_height=args.image_size // 20, max_width=args.image_size // 20,
                            min_holes=5, fill_value=0, mask_fill_value=0, p=0.5),
            ], p=1.0),

        "train_strong":
            A.Compose([
                A.OneOf([A.Resize(*[args.image_size, args.image_size], interpolation=cv2.INTER_NEAREST, p=1.0), ], p=1),

                A.HorizontalFlip(p=0.5),
                A.VerticalFlip(p=0.5),
                A.RandomBrightnessContrast(p=0.6),
                A.ShiftScaleRotate(shift_limit=0.0625, scale_limit=0.05, rotate_limit=10, p=0.5),

                A.OneOf([
                    A.GridDistortion(num_steps=5, distort_limit=0.05, p=1.0),
                    A.ElasticTransform(alpha=1, sigma=50, alpha_affine=50, p=1.0)
                ], p=0.5),
                A.CoarseDropout(max_holes=20, max_height=256 // 20, max_width=256 // 20,
                                min_holes=10, fill_value=0, mask_fill_value=0, p=0.7),
            ], p=1.0),


        "valid_test": A.Compose([
            A.Resize(*[args.image_size, args.image_size], interpolation=cv2.INTER_NEAREST),
        ], p=1.0)
    }
    return data_transforms


def build_cervix_weak_strong_transforms(args):
    """
    构建用于半监督训练的弱增强和强增强。
    返回值为一个包含 train_weak, train_strong, valid_test 的字典。
    """
    data_transforms = {
        "train_weak":
            A.Compose([
                A.Resize(args.image_height, args.image_width, interpolation=cv2.INTER_NEAREST),
                #A.RandomCrop(height=args.image_height, width=args.image_width, always_apply=True),
                A.HorizontalFlip(p=0.5),
                A.VerticalFlip(p=0.5),
                A.RandomBrightnessContrast(p=0.2),
                A.ShiftScaleRotate(shift_limit=0.0625, scale_limit=0.05, rotate_limit=10, p=0.5),
                # A.CoarseDropout(
                #     max_holes=8,
                #     max_height=args.image_height // 20,
                #     max_width=args.image_width // 20,
                #     min_holes=5,
                #     fill_value=0,
                #     mask_fill_value=0,
                #     p=0.5
                # ),
            ], p=1.0),

        "train_strong":
            A.Compose([
                A.Resize(args.image_height, args.image_width, interpolation=cv2.INTER_NEAREST),
                #A.RandomCrop(height=args.image_height, width=args.image_width, always_apply=True),
                A.HorizontalFlip(p=0.5),
                A.VerticalFlip(p=0.5),
                A.RandomBrightnessContrast(p=0.6),
                A.ShiftScaleRotate(shift_limit=0.0625, scale_limit=0.05, rotate_limit=10, p=0.5),
                A.OneOf([
                    A.GridDistortion(num_steps=5, distort_limit=0.05, p=1.0),
                    A.ElasticTransform(alpha=1, sigma=50, alpha_affine=50, p=1.0)
                ], p=0.5),
                # A.CoarseDropout(
                #     max_holes=20,
                #     max_height=args.image_height // 20,
                #     max_width=args.image_width // 20,
                #     min_holes=10,
                #     fill_value=0,
                #     mask_fill_value=0,
                #     p=0.7
                # ),
            ], p=1.0),

        "valid_test":
            A.Compose([
                A.Resize(args.image_height, args.image_width, interpolation=cv2.INTER_NEAREST),
            ], p=1.0)
    }

    return data_transforms

def build_eye_weak_strong_transforms(args):
    import albumentations as A
    from albumentations.pytorch import ToTensorV2

    def oct_normalize(image, **kwargs):
        image = image.astype('float32')
        return (image - image.mean()) / (image.std() + 1e-6)

    weak = A.Compose([
        A.Resize(args.image_height, args.image_width),
        A.HorizontalFlip(p=0.5),          # ✅ 左右 OK
        A.RandomBrightnessContrast(
            brightness_limit=0.15,
            contrast_limit=0.15,
            p=0.2
        ),
        A.Lambda(image=oct_normalize),
        ToTensorV2()
    ])

    strong = A.Compose([
        # A.Resize(args.image_height, args.image_width),
        A.Resize(args.image_width, args.image_height),
        A.HorizontalFlip(p=0.5),
        A.RandomBrightnessContrast(
            brightness_limit=0.2,
            contrast_limit=0.2,
            p=0.3
        ),
        A.GaussNoise(var_limit=(5.0, 20.0), p=0.1),  # ⚠️ 很轻
        A.Lambda(image=oct_normalize),
        ToTensorV2()
    ])

    valid_test = A.Compose([
        A.Resize(args.image_height, args.image_width),
        A.Lambda(image=oct_normalize),
        ToTensorV2()
    ])

    return {
        'train_weak': weak,
        'train_strong': strong,
        'valid_test': valid_test
    }







def build_oct_weak_strong_transforms1(args):
    """
    构建用于半监督训练的弱增强和强增强。
    返回值为一个包含 train_weak, train_strong, valid_test 的字典。
    """
    OCT_DEFAULT_MEAN = (0.3124, 0.3124, 0.3124)
    OCT_DEFAULT_STD = (0.2206, 0.2206, 0.2206)

    data_transforms = {
        "train_weak":
            A.Compose([
                A.RandomCrop(height=args.image_height, width=args.image_width, always_apply=True),
                A.HorizontalFlip(p=0.5),
                A.VerticalFlip(p=0.3),
                A.RandomBrightnessContrast(brightness_limit=0.2, contrast_limit=0.2, p=0.6),
                A.GaussianBlur(p=0.2),
                A.Normalize(mean=OCT_DEFAULT_MEAN, std=OCT_DEFAULT_STD),
                ToTensorV2()
            ], p=1.0),

        "train_strong":
            A.Compose([
                A.RandomCrop(height=args.image_height, width=args.image_width, always_apply=True),
                A.HorizontalFlip(p=0.5),
                A.VerticalFlip(p=0.3),
                A.RandomBrightnessContrast(brightness_limit=0.3, contrast_limit=0.3, p=0.7),
                A.OneOf([
                    A.GaussianBlur(p=1.0),
                    A.MotionBlur(p=1.0),
                ], p=0.3),
                A.ShiftScaleRotate(shift_limit=0.0625, scale_limit=0.05, rotate_limit=15, p=0.5),
                A.CoarseDropout(
                    max_holes=12,
                    max_height=args.image_height // 20,
                    max_width=args.image_width // 20,
                    min_holes=6,
                    fill_value=0,
                    mask_fill_value=0,
                    p=0.6
                ),
                A.Normalize(mean=OCT_DEFAULT_MEAN, std=OCT_DEFAULT_STD),
                ToTensorV2()
            ], p=1.0),

        "valid_test":
            A.Compose([
                # 一般测试时不需要增强，只进行归一化和转为tensor等操作
                A.Resize(height=args.image_height, width=args.image_width, always_apply=True),
                A.Normalize(mean=OCT_DEFAULT_MEAN, std=OCT_DEFAULT_STD),
                ToTensorV2()
            ], p=1.0)
    }

    # 添加 mask_transform，确保标签只做几何变换
    mask_transforms = {
        "train_weak": A.Compose([
            A.RandomCrop(height=args.image_height, width=args.image_width, always_apply=True),
            A.HorizontalFlip(p=0.5),
            A.VerticalFlip(p=0.3),
        ], p=1.0),

        "train_strong": A.Compose([
            A.RandomCrop(height=args.image_height, width=args.image_width, always_apply=True),
            A.HorizontalFlip(p=0.5),
            A.VerticalFlip(p=0.3),
        ], p=1.0),

        "valid_test": A.Compose([
            A.Resize(height=args.image_height, width=args.image_width, always_apply=True),
        ], p=1.0)
    }

    return data_transforms, mask_transforms


def build_oct_transforms(args):
    """构建图像和掩码的同步增强管道"""
    OCT_MEAN = (0.3124, 0.3124, 0.3124)
    OCT_STD = (0.2206, 0.2206, 0.2206)

    # 基础几何变换（图像和掩码同步）
    base_transform = [
        A.RandomCrop(height=args.image_height, width=args.image_width, always_apply=True),
        A.HorizontalFlip(p=0.5),
        A.VerticalFlip(p=0.3)
    ]

    # 弱增强（仅颜色变换作用于图像）
    train_weak = A.Compose([
        *base_transform,
        A.RandomBrightnessContrast(brightness_limit=0.2, contrast_limit=0.2, p=0.6),
        A.GaussianBlur(p=0.2),
        A.Normalize(mean=OCT_MEAN, std=OCT_STD),
        ToTensorV2()
    ], additional_targets={'mask': 'mask'})

    # 强增强（更剧烈的颜色+空间变换）
    train_strong = A.Compose([
        *base_transform,
        A.RandomBrightnessContrast(brightness_limit=0.3, contrast_limit=0.3, p=0.7),
        A.OneOf([A.GaussianBlur(), A.MotionBlur()], p=0.3),
        A.ShiftScaleRotate(shift_limit=0.0625, scale_limit=0.05, rotate_limit=15, p=0.5),
        A.CoarseDropout(
            max_holes=12, max_height=args.image_height//20, max_width=args.image_width//20,
            min_holes=6, fill_value=0, mask_fill_value=0, p=0.6
        ),
        A.Normalize(mean=OCT_MEAN, std=OCT_STD),
        ToTensorV2()
    ], additional_targets={'mask': 'mask'})

    # 验证/测试集（仅归一化和调整大小）
    valid_test = A.Compose([
        A.Resize(height=args.image_height, width=args.image_width),
        A.Normalize(mean=OCT_MEAN, std=OCT_STD),
        ToTensorV2()
    ], additional_targets={'mask': 'mask'})

    return {
        'train_weak': train_weak,
        'train_strong': train_strong,
        'valid_test': valid_test
    }


