import os
from pathlib import Path
import pandas as pd

# ========= 修改这里 =========
ROOT = Path("../../OCT5k")
IMAGE_ROOT = ROOT / "image"
MASK_ROOT = ROOT / "mask"
OUTPUT_XLSX = "oct5k_segmentation.xlsx"

CLASSES = ["AMD", "DME", "Normal"]

IMAGE_EXTS = [".tif", ".tiff", ".TIF", ".TIFF"]
MASK_EXTS = [".png", ".PNG", ".tif", ".tiff"]
# ============================


def find_mask(mask_case_dir: Path, image_stem: str):
    """根据 image 主文件名，在 mask 目录中找对应文件"""
    for ext in MASK_EXTS:
        p = mask_case_dir / (image_stem + ext)
        if p.exists():
            return p
    return None


records = []

for cls in CLASSES:
    image_cls_dir = IMAGE_ROOT / cls
    mask_cls_dir = MASK_ROOT / cls

    if not image_cls_dir.exists():
        print(f"[Skip] Missing image class folder: {image_cls_dir}")
        continue

    for case_dir in sorted(image_cls_dir.iterdir()):
        if not case_dir.is_dir():
            continue

        mask_case_dir = mask_cls_dir / case_dir.name
        if not mask_case_dir.exists():
            print(f"[Skip] Missing mask case folder: {mask_case_dir}")
            continue

        for img_path in sorted(case_dir.iterdir()):
            if img_path.suffix not in IMAGE_EXTS:
                continue

            mask_path = find_mask(mask_case_dir, img_path.stem)

            if mask_path is None:
                print(f"[Skip] Mask not found: {img_path}")
                continue

            records.append({
                "image_path": str(img_path.resolve()),
                "mask_path": str(mask_path.resolve()),
                "label": cls
            })

# 保存 xlsx
df = pd.DataFrame(records)
df.to_excel(OUTPUT_XLSX, index=False)

print(f"\n✅ Done!")
print(f"Total samples: {len(df)}")
print(f"Saved to: {OUTPUT_XLSX}")
