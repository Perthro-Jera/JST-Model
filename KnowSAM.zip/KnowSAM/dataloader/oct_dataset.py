import torch
from torch.utils.data import Dataset
import pandas as pd
import cv2
import numpy as np
import os

from torch.utils.data import Dataset
import pandas as pd
import cv2
import numpy as np
import albumentations as A
import tifffile


class OctDataset(Dataset):
    def __init__(self, xlsx_path, transform=None, labeled_num=None, mode="train"):
        """
        xlsx_path: Excel 路径，第一列是 image_path，第二列是 mask_path
        transform: {'train_weak': ..., 'train_strong': ..., 'valid_test': ...}
        labeled_num: 有标签数据的数量（仅用于训练）
        mode: 'train' or 'val' or 'test'
        """
        self.data = pd.read_excel(xlsx_path)
        self.image_paths = self.data.iloc[:, 0].tolist()
        self.mask_paths = self.data.iloc[:, 1].tolist()

        self.mode = mode
        self.transform = transform

        if self.mode == "train":
            total = len(self.image_paths)
            print(f"[INFO] Total training samples: {total}")
            if labeled_num is None or labeled_num > total:
                labeled_num = total  # 防止越界
            self.labeled_indices = list(range(labeled_num))
            self.unlabeled_indices = list(range(labeled_num, total))
            print(f"[INFO] Labeled samples: {len(self.labeled_indices)}, Unlabeled samples: {len(self.unlabeled_indices)}")
        else:
            total = len(self.image_paths)
            print(f"[INFO] Total testing samples: {total}")
            self.labeled_indices = list(range(len(self.image_paths)))
            self.unlabeled_indices = []

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        mask_path = self.mask_paths[idx]


        image = cv2.cvtColor(cv2.imread(img_path), cv2.COLOR_BGR2RGB)
        mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
        #image = image.astype(np.uint8)


        mask = mask.astype(np.uint8)
        #image = image.astype(np.float32) / 255.0


        mask = mask.astype(np.float64)

        if self.mode == "train":
            if idx in self.labeled_indices:
                aug = self.transform["train_weak"]
            else:
                aug = self.transform["train_strong"]
        else:
            aug = self.transform["valid_test"]

        if aug is not None:
            transformed = aug(image=image, mask=mask)
            image = transformed["image"]
            mask = transformed["mask"]

        OCT_DEFAULT_MEAN = (0.3124, 0.3124, 0.3124)
        OCT_DEFAULT_STD = (0.2206, 0.2206, 0.2206)
        # 归一化图像
        normalize_transform = A.Compose([
            A.Normalize(mean=OCT_DEFAULT_MEAN, std=OCT_DEFAULT_STD)
        ])

        # 将图像转换为float32类型，并应用归一化
        image = normalize_transform(image=image)['image']
        image = image.transpose(2, 0, 1)  # HWC -> CHW
        return {
            "image": image,
            "label": mask,
            "is_labeled": idx in self.labeled_indices
        }


class OctCervixDataset(Dataset):
    def __init__(self, xlsx_path, transform=None, labeled_num=None, mode="train"):
        """
        xlsx_path: Excel 路径，第一列是 image_path，第二列是 mask_path（无标签样本此列为空）
        transform: {'train_weak': ..., 'train_strong': ..., 'valid_test': ...}
        labeled_num: 有标签数据的数量（仅用于训练）
        mode: 'train' or 'val' or 'test'
        """
        self.data = pd.read_excel(xlsx_path)
        self.image_paths = self.data.iloc[:, 0].tolist()
        self.mask_paths = self.data.iloc[:, 1].tolist()

        self.mode = mode
        self.transform = transform

        total = len(self.image_paths)

        if self.mode == "train":
            print(f"[INFO] Total training samples: {total}")
            if labeled_num is None or labeled_num > total:
                labeled_num = total
            self.labeled_indices = list(range(labeled_num))
            self.unlabeled_indices = list(range(labeled_num, total))
            print(f"[INFO] Labeled samples: {len(self.labeled_indices)}, Unlabeled samples: {len(self.unlabeled_indices)}")
        else:
            print(f"[INFO] Total testing samples: {total}")
            self.labeled_indices = list(range(len(self.image_paths)))
            self.unlabeled_indices = []

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        image = cv2.cvtColor(cv2.imread(img_path), cv2.COLOR_BGR2RGB)

        is_labeled = idx in self.labeled_indices

        if is_labeled:
            mask_path = self.mask_paths[idx]
            mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE).astype(np.uint8)
        else:
            # 用零掩码填充，保持输出结构一致（可选：返回 None）
            mask = np.zeros((image.shape[0], image.shape[1]), dtype=np.uint8)

        # 选择对应增强策略
        if self.mode == "train":
            aug = self.transform["train_weak"] if is_labeled else self.transform["train_strong"]
        else:
            aug = self.transform["valid_test"]

        if aug is not None:
            transformed = aug(image=image, mask=mask)
            image = transformed["image"]
            mask = transformed["mask"]

        OCT_DEFAULT_MEAN = (0.3124, 0.3124, 0.3124)
        OCT_DEFAULT_STD = (0.2206, 0.2206, 0.2206)

        normalize_transform = A.Compose([
            A.Normalize(mean=OCT_DEFAULT_MEAN, std=OCT_DEFAULT_STD)
        ])
        image = normalize_transform(image=image)['image']
        image = image.transpose(2, 0, 1)

        return {
            "image": image,
            "label": mask,
            "is_labeled": is_labeled
        }

class OctEyeDataset(Dataset):
    def __init__(self, xlsx_path, transform=None, labeled_num=None, mode="train"):
        """
        xlsx_path: Excel 路径，第一列是 image_path，第二列是 mask_path（无标签样本此列为空）
        transform: {'train_weak': ..., 'train_strong': ..., 'valid_test': ...}
        labeled_num: 有标签数据的数量（仅用于训练）
        mode: 'train' or 'val' or 'test'
        """
        self.data = pd.read_excel(xlsx_path)
        self.image_paths = self.data.iloc[:, 0].tolist()
        self.mask_paths = self.data.iloc[:, 1].tolist()
        self.mode = mode
        self.transform = transform

        total = len(self.image_paths)

        if self.mode == "train":
            print(f"[INFO] Total training samples: {total}")
            if labeled_num is None or labeled_num > total:
                labeled_num = total
            self.labeled_indices = list(range(labeled_num))
            self.unlabeled_indices = list(range(labeled_num, total))
            print(f"[INFO] Labeled samples: {len(self.labeled_indices)}, Unlabeled samples: {len(self.unlabeled_indices)}")
        else:
            print(f"[INFO] Total testing samples: {total}")
            self.labeled_indices = list(range(len(self.image_paths)))
            self.unlabeled_indices = []

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        is_labeled = idx in self.labeled_indices

        # ------------------ 读取 OCT TIFF ------------------
        import tifffile
        img = tifffile.imread(img_path)  # 自动读取 8-bit 或 16-bit
        if img.ndim == 2:  # 灰度图，扩成 3 通道
            img = np.stack([img] * 3, axis=-1)
        elif img.shape[2] == 1:  # 单通道，也扩成 3 通道
            img = np.repeat(img, 3, axis=2)

        # 转 float32 并归一化到 [0,1]
        if img.dtype == np.uint16:
            image = img.astype(np.float32) / 65535.0
        else:
            image = img.astype(np.float32) / 255.0

        # ------------------ 读取 mask ------------------
        if is_labeled:
            mask_path = self.mask_paths[idx]
            mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE).astype(np.uint8)
        else:
            # 无标签时生成全 0 mask
            mask = np.zeros((image.shape[0], image.shape[1]), dtype=np.uint8)

        # ------------------ resize 到统一大小 ------------------
        target_h, target_w = 512, 512  # 你可以改成 args.image_height/width
        image = cv2.resize(image, (target_w, target_h)).astype(np.float32)
        mask = cv2.resize(mask, (target_w, target_h), interpolation=cv2.INTER_NEAREST).astype(np.uint8)

        # ------------------ 数据增强 ------------------
        if self.mode == "train":
            aug = self.transform["train_weak"] if is_labeled else self.transform["train_strong"]
        else:
            aug = self.transform.get("valid_test", None)

        if aug is not None:
            assert isinstance(image, np.ndarray), f"[ERROR] image type {type(image)}, idx={idx}, path={img_path}"
            assert isinstance(mask, np.ndarray), f"[ERROR] mask type {type(mask)}, idx={idx}, path={img_path}"
            transformed = aug(image=image, mask=mask)
            image = transformed["image"]
            mask = transformed["mask"]

        # ------------------ 标准化 ------------------
        OCT_DEFAULT_MEAN = (0.5, 0.5, 0.5)
        OCT_DEFAULT_STD = (0.5, 0.5, 0.5)
        normalize_transform = A.Compose([
            A.Normalize(mean=OCT_DEFAULT_MEAN, std=OCT_DEFAULT_STD)
        ])

        return {
            "image": image,
            "label": mask,
            "is_labeled": is_labeled
        }


