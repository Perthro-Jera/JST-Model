import cv2
import torch
import numpy as np
import math
import os
import sys
import shutil
import random
import albumentations as A
from skimage import feature
import torch.nn.functional as F

from albumentations.pytorch.transforms import ToTensorV2
from torchvision import transforms


OCT_DEFAULT_MEAN = (0.3124, 0.3124, 0.3124)
OCT_DEFAULT_STD = (0.2206, 0.2206, 0.2206)

class DataUpdater(object):
    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

class DAForTransUnetTest(object):
    def __init__(self, args):
        self.transform = A.Compose([
            A.Resize(height=args.frame_height, width=args.frame_width, always_apply=True),
        ])
        self.img_transform = A.Compose([
            A.Normalize(mean=OCT_DEFAULT_MEAN,
                        std=OCT_DEFAULT_STD),
            ToTensorV2()
        ])

    def __call__(self, image, mask):
        augmented = self.transform(image=image, mask=mask)
        image = augmented['image']
        mask = augmented['mask']  # [H, W] 这个地方先对mask不做处理，就是int8的二维数组
        mask = torch.from_numpy(mask)
        image = self.img_transform(image=image)['image']  # [3, H, W] torch.Tensor
        return image, mask

class ImageProcessor(object):
    def __init__(self, args, augmentation='train'):
        self.augmentation = augmentation
        self.args = args

    def __call__(self, img, mask):

        if self.augmentation in ["test"]:
             # MedNeXt的训练数据集预处理
            if self.args.model_name == 'MedNeXt':
                data_augmentation = DAForTransUnetTest(self.args)
        else:
            print('not support data augmentation type !')
            sys.exit(-1)
        img, mask = data_augmentation(img, mask)
        return img, mask

def seeding(seed):
    """
    Set the seed for randomness.
    :param seed: int; the seed for randomness.
    :return: None.
    """
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    # torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.deterministic = True
    # torch.backends.cudnn.enabled = False