import pandas as pd
import cv2
import os

# 修改为你的 Excel 路径
xlsx_path = "oct5k_segmentation.xlsx"  # 或 data1000.xlsx
save_txt = "mismatch_list.txt"

# 读取 Excel
data = pd.read_excel(xlsx_path)
image_paths = data.iloc[:, 0].tolist()
mask_paths = data.iloc[:, 1].tolist()

mismatch_list = []

for idx, (img_path, mask_path) in enumerate(zip(image_paths, mask_paths)):
    if not os.path.exists(img_path):
        print(f"[WARNING] Image file does not exist: {img_path}")
        continue

    image = cv2.imread(img_path)
    if image is None:
        print(f"[WARNING] Failed to read image: {img_path}")
        continue

    h_img, w_img = image.shape[:2]

    # 如果 mask 路径为空，跳过
    if pd.isna(mask_path) or mask_path == "":
        continue

    if not os.path.exists(mask_path):
        print(f"[WARNING] Mask file does not exist: {mask_path}")
        continue

    mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
    if mask is None:
        print(f"[WARNING] Failed to read mask: {mask_path}")
        continue

    h_mask, w_mask = mask.shape

    if (h_img, w_img) != (h_mask, w_mask):
        print(f"[MISMATCH] idx={idx} Image: {img_path} ({h_img},{w_img}), Mask: {mask_path} ({h_mask},{w_mask})")
        mismatch_list.append((idx, img_path, mask_path, (h_img, w_img), (h_mask, w_mask)))

# 保存到文件
if mismatch_list:
    with open(save_txt, "w") as f:
        for idx, img_path, mask_path, img_shape, mask_shape in mismatch_list:
            f.write(f"{idx}\t{img_path}\t{mask_path}\t{img_shape}\t{mask_shape}\n")
    print(f"\nTotal mismatches: {len(mismatch_list)}. Saved to {save_txt}")
else:
    print("All images and masks have matching sizes.")
