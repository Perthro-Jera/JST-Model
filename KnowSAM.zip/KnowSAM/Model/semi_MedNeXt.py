from Model.unet import DownBlock, UpBlock
from Model.vnet import DownsamplingConvBlock, UpsamplingDeconvBlock
from Model.vnet import ConvBlock as vnet_ConvBlock
from Model.unet import ConvBlock as unet_ConvBlock
from Model.discriminator import Discriminator
from .blocks import *
import torch
from einops import rearrange, repeat
from einops.layers.torch import Rearrange
from torch import nn, einsum


class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, dropout=0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        return self.net(x)


class Attention(nn.Module):
    def __init__(self, dim, num_heads=8, dim_head=64, dropout=0.1):
        super().__init__()
        inner_dim = dim_head * num_heads
        self.num_heads = num_heads

        self.w_q = nn.Linear(dim, inner_dim)
        self.w_k = nn.Linear(dim, inner_dim)
        self.w_v = nn.Linear(dim, inner_dim)

        self.scale = dim_head ** -0.5
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        project_out = not (num_heads == 1 and dim_head == dim)
        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout),
        ) if project_out else nn.Identity()

    def forward(self, p1, p2):
        q_p1 = self.w_q(p1)
        k_p2 = self.w_k(p2)
        v_p2 = self.w_v(p2)
        q_p1 = rearrange(q_p1, 'b n (h d) -> b h n d', h=self.num_heads)
        k_p2 = rearrange(k_p2, 'b n (h d) -> b h n d', h=self.num_heads)
        v_p2 = rearrange(v_p2, 'b n (h d) -> b h n d', h=self.num_heads)

        attn_p1p2 = einsum('b h i d, b h j d -> b h i j', q_p1, k_p2) * self.scale
        attn_p1p2 = attn_p1p2.softmax(dim=-1)
        # show(attn_p1p2)
        attn_p1p2 = einsum('b h i j, b h j d -> b h i d', attn_p1p2, v_p2)
        attn_p1p2 = rearrange(attn_p1p2, 'b h n d -> b n (h d)')

        attn_p1p2 = self.to_out(attn_p1p2)
        return attn_p1p2


class Cross_Attention_block(nn.Module):
    def __init__(self, input_size, in_channels, patch_size=16, num_heads=8, channel_attn_drop=0.1, pos_embed=True,
                 dim=96, dim_head=64, hid_dim=384):
        super(Cross_Attention_block, self).__init__()
        self.patch_size = patch_size
        input_size = int(input_size)
        assert input_size % self.patch_size == 0, 'Image dimensions must be divisible by the patch size.'
        num_patches = (input_size // patch_size) ** 2

        patch_dim = in_channels * patch_size ** 2
        self.to_patch_embedding = nn.Sequential(
            Rearrange('b c (h p1) (w p2) -> b (h w) (p1 p2 c)', p1=patch_size, p2=patch_size),
            nn.Linear(patch_dim, dim)
        )
        self.dropout = nn.Dropout(channel_attn_drop)

        self.attn = Attention(dim, num_heads, dim_head, channel_attn_drop)

        if pos_embed:
            # self.pos_embed = nn.Parameter(torch.zeros(1, num_patches+1, dim))
            self.pos_embed = nn.Parameter(torch.randn(1, num_patches, dim))
        else:
            self.pos_embed = None

        self.MLP = FeedForward(dim, hid_dim)

        self.to_out = nn.Sequential(
            nn.Linear(dim, patch_dim),
            nn.Dropout(channel_attn_drop),
            Rearrange('b (h w) (p1 p2 c)-> b c (h p1) (w p2) ', h=(input_size // patch_size),
                      w=(input_size // patch_size), p1=patch_size, p2=patch_size),
        )

    def forward(self, p1, p2):

        p1 = self.to_patch_embedding(p1)
        p2 = self.to_patch_embedding(p2)
        _, n, _ = p1.shape  # n表示每个块的空间分辨率

        if self.pos_embed is not None:
            p1 = p1 + self.pos_embed
            p2 = p2 + self.pos_embed
        p1 = self.dropout(p1)
        p2 = self.dropout(p2)

        attn_p1p2 = self.attn(p1, p2)

        attn_p1p2 = self.MLP(attn_p1p2) + attn_p1p2
        attn_p1p2 = self.to_out(attn_p1p2)
        # show_attn(attn_p1p2)
        return attn_p1p2


class VNet(nn.Module):
    def __init__(self, n_channels=3, n_classes=2, n_filters=16, normalization='none', has_dropout=False):
        super(VNet, self).__init__()
        self.has_dropout = has_dropout
        self.block_one = vnet_ConvBlock(1, n_channels, n_filters, normalization=normalization)
        self.block_one_dw = DownsamplingConvBlock(n_filters, 2 * n_filters, normalization=normalization)

        self.block_two = vnet_ConvBlock(2, n_filters * 2, n_filters * 2, normalization=normalization)
        self.block_two_dw = DownsamplingConvBlock(n_filters * 2, n_filters * 4, normalization=normalization)

        self.block_three = vnet_ConvBlock(3, n_filters * 4, n_filters * 4, normalization=normalization)
        self.block_three_dw = DownsamplingConvBlock(n_filters * 4, n_filters * 8, normalization=normalization)

        self.block_four = vnet_ConvBlock(3, n_filters * 8, n_filters * 8, normalization=normalization)
        self.block_four_dw = DownsamplingConvBlock(n_filters * 8, n_filters * 16, normalization=normalization)

        self.block_five = vnet_ConvBlock(3, n_filters * 16, n_filters * 16, normalization=normalization)
        self.block_five_up = UpsamplingDeconvBlock(n_filters * 16, n_filters * 8, normalization=normalization)

        self.block_six = vnet_ConvBlock(3, n_filters * 8, n_filters * 8, normalization=normalization)
        self.block_six_up = UpsamplingDeconvBlock(n_filters * 8, n_filters * 4, normalization=normalization)

        self.block_seven = vnet_ConvBlock(3, n_filters * 4, n_filters * 4, normalization=normalization)
        self.block_seven_up = UpsamplingDeconvBlock(n_filters * 4, n_filters * 2, normalization=normalization)

        self.block_eight = vnet_ConvBlock(2, n_filters * 2, n_filters * 2, normalization=normalization)
        self.block_eight_up = UpsamplingDeconvBlock(n_filters * 2, n_filters, normalization=normalization)

        self.block_nine = vnet_ConvBlock(1, n_filters, n_filters, normalization=normalization)
        self.out_conv = nn.Conv2d(n_filters, n_classes, 1, padding=0)

        self.dropout = nn.Dropout2d(p=0.5, inplace=False)

        self.__init_weight()

    def __init_weight(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
                torch.nn.init.kaiming_normal_(m.weight)
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()






class UNet(nn.Module):
    def __init__(self, in_chns, class_num, bilinear):
        super(UNet, self).__init__()
        params = {'in_chns': in_chns,
                  'feature_chns': [16, 32, 64, 128, 256],
                  'dropout': [0.05, 0.1, 0.2, 0.3, 0.5],
                  'class_num': class_num,
                  'bilinear': bilinear,
                  'acti_func': 'relu',
                  }
        self.params = params
        self.n_class = self.params['class_num']
        self.in_chns = self.params['in_chns']
        self.ft_chns = self.params['feature_chns']
        self.bilinear = self.params['bilinear']
        self.dropout = self.params['dropout']
        assert (len(self.ft_chns) == 5)

        self.in_conv = unet_ConvBlock(
            self.in_chns, self.ft_chns[0], self.dropout[0])
        self.down1 = DownBlock(
            self.ft_chns[0], self.ft_chns[1], self.dropout[1])
        self.down2 = DownBlock(
            self.ft_chns[1], self.ft_chns[2], self.dropout[2])
        self.down3 = DownBlock(
            self.ft_chns[2], self.ft_chns[3], self.dropout[3])
        self.down4 = DownBlock(
            self.ft_chns[3], self.ft_chns[4], self.dropout[4])

        self.up1 = UpBlock(
            self.ft_chns[4], self.ft_chns[3], self.ft_chns[3], dropout_p=0.0, bilinear=self.bilinear)
        self.up2 = UpBlock(
            self.ft_chns[3], self.ft_chns[2], self.ft_chns[2], dropout_p=0.0, bilinear=self.bilinear)
        self.up3 = UpBlock(
            self.ft_chns[2], self.ft_chns[1], self.ft_chns[1], dropout_p=0.0, bilinear=self.bilinear)
        self.up4 = UpBlock(
            self.ft_chns[1], self.ft_chns[0], self.ft_chns[0], dropout_p=0.0, bilinear=self.bilinear)
        self.out_conv = nn.Conv2d(self.ft_chns[0], self.n_class,
                                  kernel_size=3, padding=1)

class MedNeXt(nn.Module):

    def __init__(self,
                 in_channels: int,
                 n_channels: int,
                 n_classes: int,
                 exp_r: int = 2,  # Expansion ratio as in Swin Transformers
                 kernel_size: int = 3,  # Ofcourse can test kernel_size
                 enc_kernel_size: int = None,
                 dec_kernel_size: int = None,
                 deep_supervision: bool = False,  # Can be used to test deep supervision
                 do_res: bool = True,  # Can be used to individually test residual connection
                 do_res_up_down: bool = True,  # Additional 'res' connection on up and down convs
                 checkpoint_style: bool = None,  # Either inside block or outside block
                 block_counts: list = [2, 2, 2, 2, 2, 2, 2, 2, 2],  # Can be used to test staging ratio:
                 # [3,3,9,3] in Swin as opposed to [2,2,2,2,2] in nnUNet
                 norm_type='group',
                 dim='2d',  # 2d or 3d
                 grn=False
                 ):

        super().__init__()

        self.do_ds = deep_supervision
        self.inside_block_checkpointing = False
        self.outside_block_checkpointing = False
        assert dim in ['2d', '3d']
        if kernel_size is not None:
            enc_kernel_size = kernel_size
            dec_kernel_size = kernel_size

        if dim == '2d':
            conv = nn.Conv2d
        elif dim == '3d':
            conv = nn.Conv3d

        self.stem = conv(in_channels, n_channels, kernel_size=1)
        if type(exp_r) == int:
            exp_r = [exp_r for i in range(len(block_counts))]

        self.enc_block_0 = nn.Sequential(*[
            MedNeXtBlock(
                in_channels=n_channels,
                out_channels=n_channels,
                exp_r=exp_r[0],
                kernel_size=enc_kernel_size,
                do_res=do_res,
                norm_type=norm_type,
                dim=dim,
                grn=grn
            )
            for i in range(block_counts[0])]
                                         )

        self.down_0 = MedNeXtDownBlock(
            in_channels=n_channels,
            out_channels=2 * n_channels,
            exp_r=exp_r[1],
            kernel_size=enc_kernel_size,
            do_res=do_res_up_down,
            norm_type=norm_type,
            dim=dim
        )

        self.enc_block_1 = nn.Sequential(*[
            MedNeXtBlock(
                in_channels=n_channels * 2,
                out_channels=n_channels * 2,
                exp_r=exp_r[1],
                kernel_size=enc_kernel_size,
                do_res=do_res,
                norm_type=norm_type,
                dim=dim,
                grn=grn
            )
            for i in range(block_counts[1])]
                                         )

        self.down_1 = MedNeXtDownBlock(
            in_channels=2 * n_channels,
            out_channels=4 * n_channels,
            exp_r=exp_r[2],
            kernel_size=enc_kernel_size,
            do_res=do_res_up_down,
            norm_type=norm_type,
            dim=dim,
            grn=grn
        )

        self.enc_block_2 = nn.Sequential(*[
            MedNeXtBlock(
                in_channels=n_channels * 4,
                out_channels=n_channels * 4,
                exp_r=exp_r[2],
                kernel_size=enc_kernel_size,
                do_res=do_res,
                norm_type=norm_type,
                dim=dim,
                grn=grn
            )
            for i in range(block_counts[2])]
                                         )

        self.down_2 = MedNeXtDownBlock(
            in_channels=4 * n_channels,
            out_channels=8 * n_channels,
            exp_r=exp_r[3],
            kernel_size=enc_kernel_size,
            do_res=do_res_up_down,
            norm_type=norm_type,
            dim=dim,
            grn=grn
        )

        self.enc_block_3 = nn.Sequential(*[
            MedNeXtBlock(
                in_channels=n_channels * 8,
                out_channels=n_channels * 8,
                exp_r=exp_r[3],
                kernel_size=enc_kernel_size,
                do_res=do_res,
                norm_type=norm_type,
                dim=dim,
                grn=grn
            )
            for i in range(block_counts[3])]
                                         )

        self.down_3 = MedNeXtDownBlock(
            in_channels=8 * n_channels,
            out_channels=16 * n_channels,
            exp_r=exp_r[4],
            kernel_size=enc_kernel_size,
            do_res=do_res_up_down,
            norm_type=norm_type,
            dim=dim,
            grn=grn
        )

        self.bottleneck = nn.Sequential(*[
            MedNeXtBlock(
                in_channels=n_channels * 16,
                out_channels=n_channels * 16,
                exp_r=exp_r[4],
                kernel_size=dec_kernel_size,
                do_res=do_res,
                norm_type=norm_type,
                dim=dim,
                grn=grn
            )
            for i in range(block_counts[4])]
                                        )

        self.up_3 = MedNeXtUpBlock(
            in_channels=16 * n_channels,
            out_channels=8 * n_channels,
            exp_r=exp_r[5],
            kernel_size=dec_kernel_size,
            do_res=do_res_up_down,
            norm_type=norm_type,
            dim=dim,
            grn=grn
        )

        self.dec_block_3 = nn.Sequential(*[
            MedNeXtBlock(
                in_channels=n_channels * 8,
                out_channels=n_channels * 8,
                exp_r=exp_r[5],
                kernel_size=dec_kernel_size,
                do_res=do_res,
                norm_type=norm_type,
                dim=dim,
                grn=grn
            )
            for i in range(block_counts[5])]
                                         )

        self.up_2 = MedNeXtUpBlock(
            in_channels=8 * n_channels,
            out_channels=4 * n_channels,
            exp_r=exp_r[6],
            kernel_size=dec_kernel_size,
            do_res=do_res_up_down,
            norm_type=norm_type,
            dim=dim,
            grn=grn
        )

        self.dec_block_2 = nn.Sequential(*[
            MedNeXtBlock(
                in_channels=n_channels * 4,
                out_channels=n_channels * 4,
                exp_r=exp_r[6],
                kernel_size=dec_kernel_size,
                do_res=do_res,
                norm_type=norm_type,
                dim=dim,
                grn=grn
            )
            for i in range(block_counts[6])]
                                         )

        self.up_1 = MedNeXtUpBlock(
            in_channels=4 * n_channels,
            out_channels=2 * n_channels,
            exp_r=exp_r[7],
            kernel_size=dec_kernel_size,
            do_res=do_res_up_down,
            norm_type=norm_type,
            dim=dim,
            grn=grn
        )

        self.dec_block_1 = nn.Sequential(*[
            MedNeXtBlock(
                in_channels=n_channels * 2,
                out_channels=n_channels * 2,
                exp_r=exp_r[7],
                kernel_size=dec_kernel_size,
                do_res=do_res,
                norm_type=norm_type,
                dim=dim,
                grn=grn
            )
            for i in range(block_counts[7])]
                                         )

        self.up_0 = MedNeXtUpBlock(
            in_channels=2 * n_channels,
            out_channels=n_channels,
            exp_r=exp_r[8],
            kernel_size=dec_kernel_size,
            do_res=do_res_up_down,
            norm_type=norm_type,
            dim=dim,
            grn=grn
        )

        self.dec_block_0 = nn.Sequential(*[
            MedNeXtBlock(
                in_channels=n_channels,
                out_channels=n_channels,
                exp_r=exp_r[8],
                kernel_size=dec_kernel_size,
                do_res=do_res,
                norm_type=norm_type,
                dim=dim,
                grn=grn
            )
            for i in range(block_counts[8])]
                                         )

        self.out_0 = OutBlock(in_channels=n_channels, n_classes=n_classes, dim=dim)

        # Used to fix PyTorch checkpointing bug
        self.dummy_tensor = nn.Parameter(torch.tensor([1.]), requires_grad=True)

        if deep_supervision:
            self.out_1 = OutBlock(in_channels=n_channels * 2, n_classes=n_classes, dim=dim)
            self.out_2 = OutBlock(in_channels=n_channels * 4, n_classes=n_classes, dim=dim)
            self.out_3 = OutBlock(in_channels=n_channels * 8, n_classes=n_classes, dim=dim)
            self.out_4 = OutBlock(in_channels=n_channels * 16, n_classes=n_classes, dim=dim)

        self.block_counts = block_counts

    def forward(self, x):

        x = self.stem(x)

        x_res_0 = self.enc_block_0(x)
        x = self.down_0(x_res_0)
        x_res_1 = self.enc_block_1(x)
        x = self.down_1(x_res_1)
        x_res_2 = self.enc_block_2(x)
        x = self.down_2(x_res_2)
        x_res_3 = self.enc_block_3(x)
        x = self.down_3(x_res_3)

        x = self.bottleneck(x)
        if self.do_ds:
            x_ds_4 = self.out_4(x)

        x_up_3 = self.up_3(x)
        dec_x = x_res_3 + x_up_3
        x = self.dec_block_3(dec_x)

        if self.do_ds:
            x_ds_3 = self.out_3(x)
        del x_res_3, x_up_3

        x_up_2 = self.up_2(x)
        dec_x = x_res_2 + x_up_2
        x = self.dec_block_2(dec_x)
        if self.do_ds:
            x_ds_2 = self.out_2(x)
        del x_res_2, x_up_2

        x_up_1 = self.up_1(x)
        dec_x = x_res_1 + x_up_1
        x = self.dec_block_1(dec_x)
        if self.do_ds:
            x_ds_1 = self.out_1(x)
        del x_res_1, x_up_1

        x_up_0 = self.up_0(x)
        dec_x = x_res_0 + x_up_0
        x = self.dec_block_0(dec_x)
        del x_res_0, x_up_0, dec_x

        x = self.out_0(x)

        if self.do_ds:
            return [x, x_ds_1, x_ds_2, x_ds_3, x_ds_4]
        else:
            return x

class KnowSAM(nn.Module):
    def __init__(self, args, bilinear=False, has_dropout=False):
        super(KnowSAM, self).__init__()
        self.has_dropout = has_dropout
        self.UNet = UNet(in_chns=args.in_channels, class_num=args.num_classes, bilinear=bilinear)
        #self.VNet = VNet(n_channels=args.in_channels, n_classes=args.num_classes)
        self.MedNext = MedNeXt(in_channels=args.in_channels,n_channels=32, n_classes=args.num_classes)

        self.Discriminator = Discriminator(in_channels=args.num_classes, out_conv_channels=args.num_classes)

    def get_entropy_map(self, p):
        ent_map = -1 * torch.sum(p * torch.log(p + 1e-6), dim=1, keepdim=True)
        return ent_map

    def forward(self, x):
        x0_u = self.UNet.in_conv(x)
        x1_u = self.UNet.down1(x0_u)
        x2_u = self.UNet.down2(x1_u)
        x3_u = self.UNet.down3(x2_u)
        x4_u = self.UNet.down4(x3_u)


        # unet decoder
        x_u = self.UNet.up1(x4_u, x3_u)
        x_u = self.UNet.up2(x_u, x2_u)
        x_u = self.UNet.up3(x_u, x1_u)
        x_u = self.UNet.up4(x_u, x0_u)
        pred_UNet = self.UNet.out_conv(x_u)


        pred_MedNeXt = self.MedNext(x)


        pred_MedNeXt_soft = torch.softmax(pred_MedNeXt, dim=1)
        pred_UNet_soft = torch.softmax(pred_UNet, dim=1)

        entmap1 = self.get_entropy_map(pred_MedNeXt_soft)
        entmap2 = self.get_entropy_map(pred_UNet_soft)

        #fusion_map = self.Discriminator(pred_MedNeXt, pred_UNet_soft, pred_MedNeXt_soft, pred_UNet_soft, entmap1, entmap2)
        return pred_MedNeXt, pred_UNet, pred_MedNeXt_soft, pred_UNet_soft, pred_MedNeXt_soft



class UNet_ablation(nn.Module):
    def __init__(self, args, bilinear=False, has_dropout=False):
        super(UNet_ablation, self).__init__()
        self.has_dropout = has_dropout
        self.UNet = UNet(in_chns=args.in_channels, class_num=args.num_classes, bilinear=bilinear)
        #self.VNet = VNet(n_channels=args.in_channels, n_classes=args.num_classes)
        #self.MedNext1 = MedNeXt(in_channels=args.in_channels,n_channels=32, n_classes=args.num_classes)
        #self.MedNext2 = MedNeXt(in_channels=args.in_channels,n_channels=32, n_classes=args.num_classes)
        #self.Discriminator = Discriminator(in_channels=args.num_classes, out_conv_channels=args.num_classes)

    def get_entropy_map(self, p):
        ent_map = -1 * torch.sum(p * torch.log(p + 1e-6), dim=1, keepdim=True)
        return ent_map

    def forward(self, x):
        x0_u = self.UNet.in_conv(x)
        x1_u = self.UNet.down1(x0_u)
        x2_u = self.UNet.down2(x1_u)
        x3_u = self.UNet.down3(x2_u)
        x4_u = self.UNet.down4(x3_u)


        # unet decoder
        x_u = self.UNet.up1(x4_u, x3_u)
        x_u = self.UNet.up2(x_u, x2_u)
        x_u = self.UNet.up3(x_u, x1_u)
        x_u = self.UNet.up4(x_u, x0_u)
        pred_UNet = self.UNet.out_conv(x_u)

        pred_UNet_soft = torch.softmax(pred_UNet, dim=1)



        return  pred_UNet, 0.0, pred_UNet_soft, 0.0, 0.0

class MedNeXt_ablation(nn.Module):
    def __init__(self, args, bilinear=False, has_dropout=False):
        super(MedNeXt_ablation, self).__init__()
        self.has_dropout = has_dropout
        #self.UNet = UNet(in_chns=args.in_channels, class_num=args.num_classes, bilinear=bilinear)
        #self.VNet = VNet(n_channels=args.in_channels, n_classes=args.num_classes)
        self.MedNext1 = MedNeXt(in_channels=args.in_channels,n_channels=32, n_classes=args.num_classes)
        #self.MedNext2 = MedNeXt(in_channels=args.in_channels,n_channels=32, n_classes=args.num_classes)
        #self.Discriminator = Discriminator(in_channels=args.num_classes, out_conv_channels=args.num_classes)

    def get_entropy_map(self, p):
        ent_map = -1 * torch.sum(p * torch.log(p + 1e-6), dim=1, keepdim=True)
        return ent_map

    def forward(self, x):
        pred_MedNeXt = self.MedNext1(x)
        # pred_MedNeXt2 = self.MedNext2(x)

        pred_MedNeXt_soft = torch.softmax(pred_MedNeXt, dim=1)



        return  pred_MedNeXt, 0.0, pred_MedNeXt_soft, 0.0, 0.0









