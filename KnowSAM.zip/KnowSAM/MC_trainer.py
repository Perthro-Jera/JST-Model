import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from Model.sam.build_sam import sam_model_registry
import torch.optim as optim
from utils.losses import dice_loss, loss_diff1, loss_diff2, KDLoss, DiceLoss
import logging
from utils.utils import dice_coef
import matplotlib.pyplot as plt
import numpy as np

from Model.semi_MedNeXt import KnowSAM



ce_loss = torch.nn.CrossEntropyLoss()

class MC_Trainer(nn.Module):
    def __init__(self, args):
        super(MC_Trainer, self).__init__()
        self.args = args
        self.criterion_mse = nn.MSELoss()
        self.dice_loss = DiceLoss(args.num_classes)
        device = torch.device(f"cuda:{args.gpu}")
        self.device = device

        # 类别权重张量
        class_weights = torch.tensor(args.class_weights).float().to(device)
        self.ce_loss = nn.CrossEntropyLoss(weight=class_weights)
        self.SGDL = KnowSAM(args).to(device).train()

        self.optimizer_SGDL = torch.optim.SGD(self.SGDL.parameters(), lr=args.UNet_lr, momentum=0.9,
                                              weight_decay=0.0001)
        self.best_performance_SGDL = 0.0


    def sigmoid_rampup(self, current, rampup_length):
        """Exponential rampup from https://arxiv.org/abs/1610.02242"""
        if rampup_length == 0:
            return 1.0
        else:
            current = np.clip(current, 0.0, rampup_length)
            phase = 1.0 - current / rampup_length
            return float(np.exp(-5.0 * phase * phase))

    def entropy_loss(self, p, C=2):
        y1 = -1 * torch.sum(p * torch.log(p + 1e-6), dim=1) / torch.tensor(np.log(C)).to(self.device)
        ent = torch.mean(y1)
        return ent

    def get_entropy_map(self, p):
        ent_map = -1 * torch.sum(p * torch.log(p + 1e-6), dim=1, keepdim=True)
        return ent_map

    def get_current_consistency_weight(self, epoch):
        return self.args.consistency * self.sigmoid_rampup(epoch, self.args.consistency_rampup)

    def mix_up(self, fusion_map_soft, volume_batch, pseudo_label, labeled_label, consistency_weight, patch_size=4,
               top_k=5):
        unlabel_pseudo_label = torch.argmax(pseudo_label.clone(), dim=1)
        entropy_unlab = self.get_entropy_map(fusion_map_soft[self.args.labeled_bs:])
        entropy_lab = self.get_entropy_map(fusion_map_soft[:self.args.labeled_bs])
        pooling = nn.AdaptiveAvgPool2d((patch_size, patch_size))
        entropy_unlab = pooling(entropy_unlab).view(self.args.labeled_bs, -1)
        entropy_lab = pooling(entropy_lab).view(self.args.labeled_bs, -1)

        _, min_indices_flat = torch.topk(entropy_unlab, top_k, largest=False)
        min_indices_2d = torch.stack([min_indices_flat // patch_size, min_indices_flat % patch_size], dim=-1)
        _, min_indices_flat_lab = torch.topk(entropy_lab, top_k, largest=False)
        min_indices_2d_lab = torch.stack([min_indices_flat_lab // patch_size, min_indices_flat_lab % patch_size],
                                         dim=-1)

        labeled_volume_batch = volume_batch[:self.args.labeled_bs]
        unlabeled_volume_batch = volume_batch[self.args.labeled_bs:]

        unlabeled_volume_batch_mix = torch.zeros_like(unlabeled_volume_batch).to(self.device)
        unlabel_pseudo_label_mix = torch.zeros_like(unlabel_pseudo_label).to(self.device)
        labeled_volume_batch_mix = torch.zeros_like(labeled_volume_batch).to(self.device)
        labeled_pseudo_label_mix = torch.zeros_like(labeled_label).to(self.device)

        patch_h = int(self.args.image_height / patch_size)
        for b in range(self.args.labeled_bs):
            index = min_indices_2d[b]
            img_mask = torch.zeros((self.args.image_height, self.args.image_width)).to(self.device)
            index_lab = min_indices_2d_lab[b]
            img_mask_lab = torch.zeros((self.args.image_height, self.args.image_width)).to(self.device)
            for n in index:
                img_mask[n[0] * patch_h: (n[0] + 1) * patch_h, n[1] * patch_h: (n[1] + 1) * patch_h] = 1
            for n in index_lab:
                img_mask_lab[n[0] * patch_h: (n[0] + 1) * patch_h, n[1] * patch_h: (n[1] + 1) * patch_h] = 1

            unlabeled_volume_batch_mix[b] = labeled_volume_batch[b] * img_mask + unlabeled_volume_batch[b] * (
                        1 - img_mask)
            unlabel_pseudo_label_mix[b] = labeled_label[b] * img_mask + unlabel_pseudo_label[b] * (1 - img_mask)

            labeled_volume_batch_mix[b] = unlabeled_volume_batch[b] * img_mask_lab + labeled_volume_batch[b] * (
                        1 - img_mask_lab)
            labeled_pseudo_label_mix[b] = unlabel_pseudo_label[b] * img_mask_lab + labeled_label[b] * (1 - img_mask_lab)

        volume_batch_mix = torch.cat([labeled_volume_batch_mix, unlabeled_volume_batch_mix], dim=0)
        label_batch_mix = torch.cat([labeled_pseudo_label_mix, unlabel_pseudo_label_mix], dim=0)

        pred_UNet_mix, pred_VNet_mix, pred_UNet_soft_mix, pred_VNet_soft_mix, fusion_map_mix = self.SGDL(
            volume_batch_mix)

        pseudo_label_mix = torch.argmax(fusion_map_mix, dim=1)

        fusion_map_soft_mix = torch.softmax(fusion_map_mix, dim=1)
        UNet_sup_mixed_loss = self.ce_loss(pred_UNet_mix, label_batch_mix.long()) + self.dice_loss(pred_UNet_soft_mix,
                                                                                              label_batch_mix)
        UNet_enp_mixed_loss = self.entropy_loss(pred_UNet_soft_mix, C=2)
        UNet_cons_mixed_loss = loss_diff1(pred_UNet_soft_mix, pred_VNet_soft_mix.clone().detach())
        UNet_unsup_mixed_loss = self.ce_loss(pred_UNet_mix[self.args.labeled_bs:],
                                        pseudo_label_mix[self.args.labeled_bs:].long()) + self.dice_loss(
            pred_UNet_soft_mix[self.args.labeled_bs:], pseudo_label_mix[self.args.labeled_bs:])

        VNet_sup_mixed_loss = self.ce_loss(pred_VNet_mix, label_batch_mix.long()) + self.dice_loss(pred_VNet_soft_mix,
                                                                                              label_batch_mix)
        VNet_enp_mixed_loss = self.entropy_loss(pred_VNet_soft_mix, C=2)
        VNet_cons_mixed_loss = loss_diff2(pred_VNet_soft_mix, pred_UNet_soft_mix.clone().detach())
        VNet_unsup_mixed_loss = self.ce_loss(pred_VNet_mix[self.args.labeled_bs:],
                                        pseudo_label_mix[self.args.labeled_bs:].long()) + self.dice_loss(
            pred_VNet_soft_mix[self.args.labeled_bs:], pseudo_label_mix[self.args.labeled_bs:])

        fusion_mixed_loss = self.ce_loss(fusion_map_mix, label_batch_mix.long()) + self.dice_loss(fusion_map_soft_mix,
                                                                                             label_batch_mix)

        UNet_mixed_loss = UNet_sup_mixed_loss + 0.9 * UNet_enp_mixed_loss + consistency_weight * (
                    UNet_cons_mixed_loss + UNet_unsup_mixed_loss)
        VNet_mixed_loss = VNet_sup_mixed_loss + 0.9 * VNet_enp_mixed_loss + consistency_weight * (
                    VNet_cons_mixed_loss + VNet_unsup_mixed_loss)

        return UNet_mixed_loss, VNet_mixed_loss, fusion_mixed_loss

    def train(self, volume_batch, label_batch, iter_num):
        pred_UNet, pred_VNet, pred_UNet_soft, pred_VNet_soft, fusion_map = self.SGDL(volume_batch)

        fusion_map_soft = torch.softmax(fusion_map, dim=1)

        fusion_loss = self.ce_loss(fusion_map[:self.args.labeled_bs],
                              label_batch[:self.args.labeled_bs].long()) + self.dice_loss(
            fusion_map_soft[:self.args.labeled_bs], label_batch[:self.args.labeled_bs])

        UNet_sup_loss = self.ce_loss(pred_UNet[:self.args.labeled_bs],
                                label_batch[:self.args.labeled_bs].long()) + self.dice_loss(
            pred_UNet_soft[:self.args.labeled_bs], label_batch[:self.args.labeled_bs])
        UNet_cons_loss = loss_diff1(pred_UNet_soft, pred_VNet_soft.clone().detach())
        UNet_enp_loss = self.entropy_loss(pred_UNet_soft, C=8)

        VNet_sup_loss = self.ce_loss(pred_VNet[:self.args.labeled_bs],
                                label_batch[:self.args.labeled_bs].long()) + self.dice_loss(
            pred_VNet_soft[:self.args.labeled_bs], label_batch[:self.args.labeled_bs])
        VNet_cons_loss = loss_diff2(pred_VNet_soft, pred_UNet_soft.clone().detach())
        VNet_enp_loss = self.entropy_loss(pred_VNet_soft, C=8)

        consistency_weight = self.get_current_consistency_weight(
            iter_num // int(self.args.max_iterations / self.args.consistency_rampup)) * 10

        UNet_loss = UNet_sup_loss + 0.9 * UNet_enp_loss + consistency_weight * UNet_cons_loss
        VNet_loss = VNet_sup_loss + 0.9 * VNet_enp_loss + consistency_weight * VNet_cons_loss

        if iter_num > self.args.mixed_iterations:
            UNet_sup_mixed_loss, VNet_sup_mixed_loss, fusion_mixed_loss = self.mix_up(fusion_map_soft, volume_batch,
                                                                                      pred_VNet_soft[
                                                                                      self.args.labeled_bs:],
                                                                                      label_batch[
                                                                                      :self.args.labeled_bs],
                                                                                      consistency_weight)
            SGDL_loss = (UNet_loss + UNet_sup_mixed_loss + VNet_loss + VNet_sup_mixed_loss) / 2 + fusion_loss + fusion_mixed_loss
        else:
            SGDL_loss = (UNet_loss + VNet_loss) / 2 + fusion_loss


        self.optimizer_SGDL.zero_grad()

        SGDL_loss.backward()

        self.optimizer_SGDL.step()

        lr_ = self.args.UNet_lr * (1.0 - iter_num / self.args.max_iterations)
        for param_group in self.optimizer_SGDL.param_groups:
            param_group['lr'] = lr_

        logging.info('iteration %d : SGDL_loss : %f | fusion_loss : %f | UNet_lr_ : %10f',
                     iter_num, SGDL_loss.item(), fusion_loss.item(), lr_)
        return SGDL_loss.item(), fusion_loss.item()

    def val(self, val_loader, snapshot_path, iter_num):
        self.SGDL.eval()

        avg_dice_SGDL = 0.0
        avg_dice_unet = 0.0
        avg_dice_vnet = 0.0

        for i_batch, sampled_batch in enumerate(val_loader):
            val_image, val_label = sampled_batch["image"].to(self.device), sampled_batch["label"].to(self.device)

            with torch.no_grad():
                pred_UNet, pred_VNet, pred_UNet_soft, pred_VNet_soft, fusion_map = self.SGDL(val_image)

                fusion_map_soft = torch.softmax(fusion_map, dim=1)
                dice_SGDL = dice_coef(val_label, fusion_map_soft, thr=0.5)
                avg_dice_SGDL += dice_SGDL

                dice_unet = dice_coef(val_label, pred_UNet_soft, thr=0.5)
                avg_dice_unet += dice_unet

                dice_vnet = dice_coef(val_label, pred_VNet_soft, thr=0.5)
                avg_dice_vnet += dice_vnet

        avg_dice_SGDL = avg_dice_SGDL / len(val_loader)
        avg_dice_unet = avg_dice_unet / len(val_loader)
        avg_dice_vnet = avg_dice_vnet / len(val_loader)


        logging.info('iteration %d : '
                     '  SGDL_mean_dice : %f '
                     '  unet_mean_dice : %f '
                     '  vnet_mean_dice : %f '
                     % (iter_num, avg_dice_SGDL, avg_dice_unet, avg_dice_vnet))

        if avg_dice_SGDL > self.best_performance_SGDL:
            self.best_performance_SGDL = avg_dice_SGDL
            save_best_SGDL = os.path.join(snapshot_path, 'SGDL_best_model.pth')
            torch.save(self.SGDL.state_dict(), save_best_SGDL)
            print("Saved state_dict keys:", torch.load(save_best_SGDL).keys())

        self.SGDL.train()

    def val_crop(self, val_loader, snapshot_path, iter_num):
        self.SGDL.eval()

        avg_dice_SGDL = 0.0

        for i_batch, sampled_batch in enumerate(val_loader):
            val_image, val_label = sampled_batch["image"].to(self.device), sampled_batch["label"].to(self.device)
            print(f"Batch 0 - Label unique values: {torch.unique(val_label)}")
            print(f"Label class distribution: {torch.bincount(val_label.flatten())}")
            # 将图像转换为 NumPy 数组进行滑动窗口预测
            val_image_np = val_image.cpu().numpy().squeeze()  # HWC, float32
            val_label_np = val_label.cpu().numpy().squeeze()  # HW, uint8

            # 使用滑动窗口推理来处理整个图像
            pred_mask = sliding_window_inference_with_padding(
                image=val_image_np,
                model=self.SGDL,
                device=self.device,
                crop_size=(256, 256),  # 根据需要调整
                stride=256,  # 根据需要调整步长
                num_classes=self.args.num_classes
            )
            # 调试信息：打印一些值以检查 pred_mask
            #print(f"Batch {i_batch}: pred_mask shape: {pred_mask.shape}, pred_mask values: {pred_mask[:10]}")
            print("Prediction unique values:", np.unique(pred_mask, return_counts=True))
            plt.imshow(pred_mask, cmap='jet')
            plt.colorbar()
            plt.show()
            # 计算 Dice 系数
            #fusion_map_soft = torch.softmax(pred_mask, dim=1)  # 根据实际返回结果调整
            pred_mask = torch.tensor(pred_mask).to(self.device)
            dice_SGDL = dice_coef(val_label, pred_mask, thr=0.5)
            #print("Dice:", dice_SGDL)  # 正常值应在 [0, 1] 之间
            #print(f"Batch {i_batch}: Dice coefficient: {dice_SGDL}")

            avg_dice_SGDL += dice_SGDL


        # 计算平均 Dice
        avg_dice_SGDL = avg_dice_SGDL / len(val_loader)


        # 记录每次迭代的结果
        logging.info('iteration %d : '
                     '  SGDL_mean_dice : %f '
                     % (iter_num, avg_dice_SGDL,))

        # 保存模型（如果性能提高）
        if avg_dice_SGDL > self.best_performance_SGDL:
            self.best_performance_SGDL = avg_dice_SGDL
            save_best_SGDL = os.path.join(snapshot_path, 'SGDL_best_model.pth')
            torch.save(self.SGDL.state_dict(), save_best_SGDL)
            #print("Saved state_dict keys:", torch.load(save_best_SGDL).keys())
        self.SGDL.train()


