# train.py
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from Model.semi_MedNeXt import KnowSAM
from dataloader.oct_dataset import OctDataset
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

from utils.utils import patients_to_slices
from dataloader.transforms import build_oct_weak_strong_transforms
from dataloader.TwoStreamBatchSampler import TwoStreamBatchSampler

parser = argparse.ArgumentParser()
parser.add_argument('--data_path', type=str, default='./SampleData',
                    help='Name of Experiment')
parser.add_argument('--labeled_num', type=int, default=133,
                    help='Percentage of label quantity')
parser.add_argument('--dataset', type=str, default='OCT',
                    help='Name of Experiment')


parser.add_argument('--num_classes', type=int,  default=8,
                    help='output channel of network')
parser.add_argument('--in_channels', type=int, default=3,
                    help='input channel of network')

parser.add_argument('-lr', type=float, default=1e-4, help='initial learning rate')
parser.add_argument('-UNet_lr', type=float, default=0.01, help='initial learning rate')
parser.add_argument('-VNet_lr', type=float, default=0.01, help='initial learning rate')
parser.add_argument('--image_height', type=int, default=256, help='image_size')
parser.add_argument('--image_width', type=int, default=512, help='image_size')
parser.add_argument('--point_nums', type=int, default=5, help='points number')
parser.add_argument('--box_nums', type=int, default=1, help='boxes number')
parser.add_argument('--mod', type=str, default='sam_adpt', help='mod type:seg,cls,val_ad')
parser.add_argument("--model_type", type=str, default="vit_b", help="sam model_type")
parser.add_argument('-thd', type=bool, default=False, help='3d or not')
parser.add_argument('--batch_size', type=int, default=12,
                    help='batch_size per gpu')
parser.add_argument('--labeled_bs', type=int, default=6,
                    help='labeled_batch_size per gpu')
parser.add_argument('--seed', type=int,  default=42,
                    help='random seed')

parser.add_argument('--mixed_iterations', type=int, default=6000,
                    help='maximum epoch number to train')
parser.add_argument('--max_iterations', type=int, default=5000,
                    help='maximum epoch number to train')

parser.add_argument('--n_fold', type=int, default=1,
                    help='maximum epoch number to train')
parser.add_argument('--consistency', type=float, default=0.1,
                    help='consistency')
parser.add_argument('--consistency_rampup', type=float,
                    default=200.0, help='consistency_rampup')
parser.add_argument('--device', type=str, default='cuda')
parser.add_argument('--gpu', type=str, default='0', help='GPU id(s) to use, e.g., "0" or "0,1"')
parser.add_argument("--multimask", type=bool, default=False, help="ouput multimask")


def train():
    args = get_args()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 1. 加载模型
    model = KnowSAM(args).to(device)
    model.train()

    # 2. 优化器
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

    # 3. 数据集
    train_dataset = OctDataset(args.train_path)  # 自己替换
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=4)

    # 4. CPS loss权重
    cps_weight = 1.0

    for epoch in range(args.max_epochs):
        total_sup_loss = 0.0
        total_cps_loss = 0.0

        for batch in train_loader:
            img = batch['image'].to(device)  # [B, C, H, W]
            label = batch['label'].to(device)  # [B, H, W] (long)

            optimizer.zero_grad()

            # 5. Forward
            pred1, pred2, pred1_soft, pred2_soft, fusion_map = model(img)

            # 6. 伪标签
            pseudo_label1 = pred2_soft.argmax(dim=1)  # [B, H, W]
            pseudo_label2 = pred1_soft.argmax(dim=1)

            # 7. 计算loss
            sup_loss1 = F.cross_entropy(pred1, label)
            sup_loss2 = F.cross_entropy(pred2, label)
            cps_loss1 = F.cross_entropy(pred1, pseudo_label1)
            cps_loss2 = F.cross_entropy(pred2, pseudo_label2)

            loss = sup_loss1 + sup_loss2 + cps_weight * (cps_loss1 + cps_loss2)

            loss.backward()
            optimizer.step()

            # 8. 累计loss
            total_sup_loss += (sup_loss1.item() + sup_loss2.item())
            total_cps_loss += (cps_loss1.item() + cps_loss2.item())

        print(
            f"Epoch [{epoch + 1}/{args.max_epochs}]  Sup Loss: {total_sup_loss / len(train_loader):.4f}  CPS Loss: {total_cps_loss / len(train_loader):.4f}")

        # 可选: 每n个epoch保存模型
        if (epoch + 1) % args.save_interval == 0:
            torch.save(model.state_dict(), f'checkpoint_epoch{epoch + 1}.pth')


if __name__ == '__main__':
    train()
