import argparse
import numpy as np
import random
import torch
import os
import logging
import sys
from tqdm import tqdm
from dataloader.oct_dataset import OctCervixDataset,OctEyeDataset
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

from utils.utils import patients_to_slices
from dataloader.transforms import build_cervix_weak_strong_transforms,build_eye_weak_strong_transforms
from dataloader.TwoStreamBatchSampler import TwoStreamBatchSampler

from semi_train import MC_Trainer  # <-- 使用你改的train函数（非Trainer）


os.environ["CUDA_VISIBLE_DEVICES"] = "1"

DATASET_CONFIG = {
    'cervix': {
        'num_classes': 8,
        'in_channels': 3,
        'image_height': 256,
        'image_width': 256,
        'xlsx_path': 'dataloader/data1000.xlsx',
        'class_weights': [1.0, 0.3, 0.6, 2.0, 1.4, 0.4, 1.8, 0.4],#1000张
        'build_transforms': 'cervix'
    },
    'eye': {
        'num_classes': 6,
        'in_channels': 3,
        'image_height': 512,
        'image_width': 512,
        'xlsx_path': 'dataloader/oct5k_segmentation.xlsx',
        'class_weights': [0.6, 1.9, 2.5, 8.0, 8.5, 0.4],
        'build_transforms': 'oct'
    }
}


parser = argparse.ArgumentParser()

parser.add_argument('--labeled_num', type=int, default=300,
                    help='Percentage of label quantity')
parser.add_argument('--dataset',type=str,default='cervix',choices=['cervix', 'oct5k'],help='Dataset type')


parser.add_argument('--in_channels', type=int, default=3,
                    help='input channel of network')

parser.add_argument('-lr', type=float, default=5e-3, help='initial learning rate')
parser.add_argument('-UNet_lr', type=float, default=0.01, help='initial learning rate')
parser.add_argument('-VNet_lr', type=float, default=0.01, help='initial learning rate')
parser.add_argument('--point_nums', type=int, default=5, help='points number')
parser.add_argument('--box_nums', type=int, default=1, help='boxes number')
parser.add_argument('--mod', type=str, default='sam_adpt', help='mod type:seg,cls,val_ad')
parser.add_argument("--model_type", type=str, default="vit_b", help="sam model_type")
parser.add_argument('-thd', type=bool, default=False, help='3d or not')
parser.add_argument('--batch_size', type=int, default=8,
                    help='batch_size per gpu')
parser.add_argument('--labeled_bs', type=int, default=4,
                    help='labeled_batch_size per gpu')
parser.add_argument('--seed', type=int,  default=42,
                    help='random seed')

parser.add_argument('--mixed_iterations', type=int, default=22000,
                    help='maximum epoch number to train')
parser.add_argument('--max_iterations', type=int, default=20000,
                    help='maximum epoch number to train')

parser.add_argument('--n_fold', type=int, default=1,
                    help='maximum epoch number to train')
parser.add_argument('--conf_thresh', type=float, default=0.7, help='Confidence threshold for pseudo label selection')

parser.add_argument('--consistency', type=float, default=1,
                    help='consistency')
parser.add_argument('--consistency_rampup', type=float,
                    default=200.0, help='consistency_rampup')
parser.add_argument('--device', type=str, default='cuda')
parser.add_argument('--gpu', type=str, default='0', help='GPU id(s) to use, e.g., "0" or "0,1"')
parser.add_argument("--multimask", type=bool, default=False, help="ouput multimask")



args = parser.parse_args()


assert args.dataset in DATASET_CONFIG, f"Unknown dataset {args.dataset}"

cfg = DATASET_CONFIG[args.dataset]

args.num_classes = cfg['num_classes']
args.in_channels = cfg['in_channels']
args.image_height = cfg['image_height']
args.image_width = cfg['image_width']
args.class_weights = cfg['class_weights']


def sigmoid_rampup(current, rampup_length):
    """Exponential rampup from https://arxiv.org/abs/1610.02242"""
    if rampup_length == 0:
        return 1.0
    else:
        current = np.clip(current, 0.0, rampup_length)
        phase = 1.0 - current / rampup_length
        return float(np.exp(-5.0 * phase * phase))


def worker_init_fn(worker_id):
    random.seed(args.seed + worker_id)


def get_current_consistency_weight(epoch):
    # Consistency ramp-up from https://arxiv.org/abs/1610.02242
    return args.consistency * sigmoid_rampup(epoch, args.consistency_rampup)


def train(args, snapshot_path):

    writer = SummaryWriter(log_dir=os.path.join(snapshot_path, "tensorboard"))
    device = torch.device(f"cuda:{args.gpu}")
    batch_size = args.batch_size
    max_iterations = args.max_iterations
    # model
    trainer = MC_Trainer(args)


    # dataset
    if args.dataset == 'cervix':
        transforms = build_cervix_weak_strong_transforms(args)
        train_dataset = OctCervixDataset(xlsx_path="dataloader/data1000.xlsx",transform=transforms,labeled_num=args.labeled_num, mode="train")
    elif args.dataset == 'eye':
        transforms = build_eye_weak_strong_transforms(args)
        train_dataset = OctEyeDataset(xlsx_path="dataloader/oct5k_segmentation.xlsx", transform=transforms,labeled_num=args.labeled_num, mode="train")
    else:
        raise ValueError(f"Unsupported dataset: {args.dataset}")
    # sampler
    labeled_slice = args.labeled_num
    total_slices = len(train_dataset)
    labeled_idxs = list(range(0, labeled_slice))
    unlabeled_idxs = list(range(labeled_slice, total_slices))

    # 全监督
    # train_loader = DataLoader(train_dataset, batch_size=args.batch_size,
    #                           shuffle=True, num_workers=2, pin_memory=True,
    #                           worker_init_fn=worker_init_fn)

    # 半监督
    batch_sampler = TwoStreamBatchSampler(labeled_idxs, unlabeled_idxs, batch_size, batch_size - args.labeled_bs)
    train_loader = DataLoader(train_dataset, batch_sampler=batch_sampler, num_workers=2, pin_memory=True, worker_init_fn=worker_init_fn)

    #val_loader = DataLoader(val_dataset, batch_size=1, shuffle=False, num_workers=1)
    logging.info("{} iterations per epoch".format(len(train_loader)))
    max_epoch = max_iterations // len(train_loader) + 1
    iterator = tqdm(range(max_epoch), ncols=70)

    # else:

    iter_num = 0
    for _ in iterator:
        for i_batch, sampled_batch in enumerate(train_loader):
            volume_batch, label_batch = sampled_batch['image'].to(device), sampled_batch['label'].to(device)
            label_batch = label_batch.long()  # 加这一行！
            cls_loss, dic_loss, cps_loss, entropy_loss = trainer.train(volume_batch, label_batch, iter_num)

            # 写入 TensorBoard
            writer.add_scalar("train/Cls_loss", cls_loss, iter_num)
            writer.add_scalar("train/Dice_loss", dic_loss, iter_num)
            writer.add_scalar("train/Cps_loss", cps_loss, iter_num)
            writer.add_scalar("train/Entropy_loss", entropy_loss, iter_num)



            iter_num = iter_num + 1
            if iter_num > 0 and iter_num % 100 == 0:
                #trainer.val_crop(val_loader, snapshot_path, iter_num)
                save_best_SGDL = os.path.join(snapshot_path, 'SGDL_best_model.pth')
                #torch.save(trainer.SGDL.state_dict(), save_best_SGDL)
                torch.save(trainer.model.state_dict(), save_best_SGDL)
                print("Saving checkpoint at {}".format(save_best_SGDL))
    writer.close()



if __name__ == '__main__':
    import shutil
    for fold in range(args.n_fold):
        torch.autograd.set_detect_anomaly(True)
        random.seed(2024)
        np.random.seed(2024)
        torch.manual_seed(2024)
        torch.cuda.manual_seed(2024)

        # 根据 dataset 自动区分保存路径
        dataset_name = args.dataset.lower()  # cervix / oct5k / eye 等
        base_save_path = os.path.join("./Results", dataset_name)
        #snapshot_path = "./Results/results_OCT_resize256_nomixup30_full_ablation/fold_" + str(fold)
        snapshot_path = os.path.join(base_save_path,"oct_full_512x512")
        if not os.path.exists(snapshot_path):
            os.makedirs(snapshot_path)
        if os.path.exists(snapshot_path + '/code'):
            shutil.rmtree(snapshot_path + '/code')
        if not os.path.exists(snapshot_path + '/code'):
            os.makedirs(snapshot_path + '/code')

        shutil.copyfile("./train_semi.py", snapshot_path + "/code/train_semi.py")
        shutil.copyfile("./MC_trainer.py", snapshot_path + "/code/MC_trainer.py")

        logging.basicConfig(filename=snapshot_path+"/log.txt", level=logging.INFO,
                            format='[%(asctime)s.%(msecs)03d] %(message)s', datefmt='%H:%M:%S')
        logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
        logging.info(str(args))
        train(args, snapshot_path)
